#!/bin/bash

# Heroku Deployment Script for Task Management System
# This script automates the deployment process to Heroku

set -e

# Configuration
APP_NAME="${HEROKU_APP_NAME:-task-management-system}"
HEROKU_REGION="${HEROKU_REGION:-us}"
HEROKU_STACK="${HEROKU_STACK:-heroku-22}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check if Node.js is installed
    if ! command -v node &> /dev/null; then
        log_error "Node.js is not installed. Please install Node.js first."
        exit 1
    fi
    
    # Check if npm is installed
    if ! command -v npm &> /dev/null; then
        log_error "npm is not installed. Please install npm first."
        exit 1
    fi
    
    # Check if git is installed
    if ! command -v git &> /dev/null; then
        log_error "Git is not installed. Please install Git first."
        exit 1
    fi
    
    # Check if Heroku CLI is installed
    if ! command -v heroku &> /dev/null; then
        log_error "Heroku CLI is not installed. Please install it first:"
        log_error "https://devcenter.heroku.com/articles/heroku-cli"
        exit 1
    fi
    
    # Check if user is logged in to Heroku
    if ! heroku auth:whoami &> /dev/null; then
        log_info "Please log in to Heroku..."
        heroku login
    fi
    
    log_success "Prerequisites check completed"
}

# Initialize git repository if needed
init_git_repo() {
    if [ ! -d ".git" ]; then
        log_info "Initializing Git repository..."
        git init
        git add .
        git commit -m "Initial commit for Heroku deployment"
        log_success "Git repository initialized"
    else
        log_info "Git repository already exists"
        
        # Check if there are uncommitted changes
        if ! git diff-index --quiet HEAD --; then
            log_warning "You have uncommitted changes. Committing them..."
            git add .
            git commit -m "Pre-deployment commit - $(date)"
        fi
    fi
}

# Create or update Procfile
create_procfile() {
    log_info "Creating Procfile..."
    
    cat > Procfile << EOF
web: node server.js
worker: node worker.js
release: node scripts/release.js
EOF
    
    log_success "Procfile created"
}

# Update package.json for Heroku
update_package_json() {
    log_info "Updating package.json for Heroku deployment..."
    
    # Check if package.json exists
    if [ ! -f "package.json" ]; then
        log_info "Creating package.json..."
        cat > package.json << EOF
{
  "name": "task-management-system",
  "version": "1.0.0",
  "description": "Task Management System for Software Engineering Course",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js",
    "test": "jest",
    "build": "echo 'No build step required'",
    "heroku-postbuild": "npm run build"
  },
  "dependencies": {
    "express": "^4.18.0",
    "compression": "^1.7.4",
    "helmet": "^6.0.0",
    "cors": "^2.8.5",
    "morgan": "^1.10.0"
  },
  "devDependencies": {
    "nodemon": "^2.0.20",
    "jest": "^29.0.0"
  },
  "engines": {
    "node": ">=18.0.0",
    "npm": ">=8.0.0"
  },
  "keywords": [
    "task-management",
    "nodejs",
    "express",
    "heroku"
  ],
  "author": "Software Engineering Course",
  "license": "MIT"
}
EOF
    fi
    
    log_success "Package.json updated"
}

# Create server.js if it doesn't exist
create_server() {
    if [ ! -f "server.js" ]; then
        log_info "Creating server.js..."
        
        cat > server.js << 'EOF'
const express = require('express');
const path = require('path');
const compression = require('compression');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');

const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
}));

// CORS configuration
app.use(cors({
  origin: process.env.CORS_ORIGINS ? process.env.CORS_ORIGINS.split(',') : '*',
  credentials: true
}));

// Compression middleware
app.use(compression());

// Logging middleware
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Serve static files
app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: process.env.NODE_ENV === 'production' ? '1y' : '0'
}));

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'development',
    version: process.env.npm_package_version || '1.0.0',
    memory: process.memoryUsage(),
    port: PORT
  });
});

// Metrics endpoint
app.get('/metrics', (req, res) => {
  res.status(200).json({
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    cpu: process.cpuUsage(),
    environment: process.env.NODE_ENV || 'development',
    version: process.env.npm_package_version || '1.0.0'
  });
});

// Simple in-memory task storage (use a database in production)
let tasks = [];
let nextId = 1;

// Tasks API routes
app.get('/api/tasks', (req, res) => {
  res.json(tasks);
});

app.post('/api/tasks', (req, res) => {
  const task = {
    id: nextId++,
    title: req.body.title,
    description: req.body.description || '',
    completed: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  tasks.push(task);
  res.status(201).json(task);
});

app.get('/api/tasks/:id', (req, res) => {
  const task = tasks.find(t => t.id === parseInt(req.params.id));
  if (!task) {
    return res.status(404).json({ error: 'Task not found' });
  }
  res.json(task);
});

app.put('/api/tasks/:id', (req, res) => {
  const taskIndex = tasks.findIndex(t => t.id === parseInt(req.params.id));
  if (taskIndex === -1) {
    return res.status(404).json({ error: 'Task not found' });
  }
  
  tasks[taskIndex] = {
    ...tasks[taskIndex],
    ...req.body,
    updatedAt: new Date().toISOString()
  };
  
  res.json(tasks[taskIndex]);
});

app.delete('/api/tasks/:id', (req, res) => {
  const taskIndex = tasks.findIndex(t => t.id === parseInt(req.params.id));
  if (taskIndex === -1) {
    return res.status(404).json({ error: 'Task not found' });
  }
  
  tasks.splice(taskIndex, 1);
  res.status(204).send();
});

// SPA fallback - serve index.html for all non-API routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({
    error: 'Internal Server Error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong'
  });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  process.exit(0);
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📡 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`💚 Health check: http://localhost:${PORT}/health`);
});

module.exports = app;
EOF
        
        log_success "Server.js created"
    fi
}

# Create release script
create_release_script() {
    log_info "Creating release script..."
    
    mkdir -p scripts
    
    cat > scripts/release.js << 'EOF'
#!/usr/bin/env node

// Heroku release phase script
// This runs before the app is deployed

console.log('🚀 Running release phase...');

// Database migrations would go here
// Example: await runMigrations();

// Cache warming
console.log('Warming up cache...');

// Health checks
console.log('Running health checks...');

// Any other pre-deployment tasks
console.log('Release phase completed successfully ✅');

process.exit(0);
EOF
    
    chmod +x scripts/release.js
    
    log_success "Release script created"
}

# Install dependencies
install_dependencies() {
    log_info "Installing dependencies..."
    
    if [ -f "package-lock.json" ]; then
        npm ci
    else
        npm install
    fi
    
    log_success "Dependencies installed"
}

# Run tests
run_tests() {
    log_info "Running tests..."
    
    if npm run test --if-present; then
        log_success "All tests passed"
    else
        log_warning "Tests failed or no tests found. Continuing with deployment..."
    fi
}

# Create or update Heroku app
create_heroku_app() {
    log_info "Creating or updating Heroku app..."
    
    # Check if app already exists
    if heroku apps:info "$APP_NAME" &> /dev/null; then
        log_info "App '$APP_NAME' already exists"
    else
        log_info "Creating new Heroku app: $APP_NAME"
        heroku create "$APP_NAME" --region "$HEROKU_REGION" --stack "$HEROKU_STACK"
        
        if [ $? -eq 0 ]; then
            log_success "Heroku app created successfully"
        else
            log_error "Failed to create Heroku app"
            exit 1
        fi
    fi
    
    # Add Heroku remote if it doesn't exist
    if ! git remote get-url heroku &> /dev/null; then
        heroku git:remote -a "$APP_NAME"
        log_success "Heroku remote added"
    fi
}

# Configure environment variables
configure_environment() {
    log_info "Configuring environment variables..."
    
    # Set Node.js environment
    heroku config:set NODE_ENV=production -a "$APP_NAME"
    
    # Set other environment variables
    heroku config:set NPM_CONFIG_PRODUCTION=false -a "$APP_NAME"
    
    # Add custom environment variables if needed
    # heroku config:set DATABASE_URL=your-database-url -a "$APP_NAME"
    # heroku config:set SESSION_SECRET=$(openssl rand -base64 32) -a "$APP_NAME"
    
    log_success "Environment variables configured"
}

# Add Heroku add-ons
add_heroku_addons() {
    log_info "Adding Heroku add-ons..."
    
    # Add logging add-on (free tier)
    heroku addons:create papertrail:choklad -a "$APP_NAME" 2>/dev/null || log_warning "Papertrail add-on already exists or failed to add"
    
    # Add monitoring add-on (free tier)
    heroku addons:create newrelic:wayne -a "$APP_NAME" 2>/dev/null || log_warning "New Relic add-on already exists or failed to add"
    
    # Add Redis for caching (free tier)
    # heroku addons:create heroku-redis:mini -a "$APP_NAME" 2>/dev/null || log_warning "Redis add-on already exists or failed to add"
    
    # Add PostgreSQL database (free tier)
    # heroku addons:create heroku-postgresql:mini -a "$APP_NAME" 2>/dev/null || log_warning "PostgreSQL add-on already exists or failed to add"
    
    log_success "Add-ons configured"
}

# Deploy to Heroku
deploy_to_heroku() {
    log_info "Deploying to Heroku..."
    
    # Commit any changes
    if ! git diff-index --quiet HEAD --; then
        git add .
        git commit -m "Pre-deployment commit - $(date)"
    fi
    
    # Push to Heroku
    git push heroku main
    
    if [ $? -eq 0 ]; then
        log_success "Deployment completed successfully"
    else
        log_error "Deployment failed"
        exit 1
    fi
}

# Scale dynos
scale_dynos() {
    log_info "Scaling dynos..."
    
    # Scale web dynos
    heroku ps:scale web=1 -a "$APP_NAME"
    
    # Scale worker dynos (if needed)
    # heroku ps:scale worker=1 -a "$APP_NAME"
    
    log_success "Dynos scaled"
}

# Verify deployment
verify_deployment() {
    log_info "Verifying deployment..."
    
    # Get app URL
    APP_URL=$(heroku apps:info "$APP_NAME" --json | jq -r '.app.web_url' 2>/dev/null || echo "")
    
    if [ -n "$APP_URL" ]; then
        log_info "App URL: $APP_URL"
        
        # Wait for app to start
        log_info "Waiting for app to start..."
        sleep 30
        
        # Test health endpoint
        log_info "Testing health endpoint..."
        if curl -f -s "${APP_URL}health" > /dev/null; then
            log_success "Health check passed"
        else
            log_warning "Health check failed - app may still be starting"
        fi
        
        # Test main page
        log_info "Testing main page..."
        if curl -f -s "$APP_URL" > /dev/null; then
            log_success "Main page is accessible"
        else
            log_error "Main page is not accessible"
            
            # Show logs for debugging
            log_info "Recent logs:"
            heroku logs --tail --num=50 -a "$APP_NAME"
            exit 1
        fi
        
        # Test API endpoints
        log_info "Testing API endpoints..."
        if curl -f -s "${APP_URL}api/tasks" > /dev/null; then
            log_success "Tasks API is accessible"
        else
            log_warning "Tasks API is not accessible"
        fi
        
        log_success "Deployment verification completed"
        log_info "Your app is live at: $APP_URL"
    else
        log_warning "Could not determine app URL"
    fi
}

# Show post-deployment information
show_post_deployment_info() {
    log_success "🚀 Heroku deployment completed successfully!"
    log_info ""
    log_info "App Information:"
    heroku apps:info "$APP_NAME"
    log_info ""
    log_info "Useful commands:"
    log_info "- View logs: heroku logs --tail -a $APP_NAME"
    log_info "- Open app: heroku open -a $APP_NAME"
    log_info "- Run console: heroku run node -a $APP_NAME"
    log_info "- Scale dynos: heroku ps:scale web=2 -a $APP_NAME"
    log_info "- Set config: heroku config:set KEY=value -a $APP_NAME"
    log_info "- View config: heroku config -a $APP_NAME"
    log_info "- Restart app: heroku restart -a $APP_NAME"
    log_info ""
    log_info "Next steps:"
    log_info "1. Configure custom domain: heroku domains:add yourdomain.com -a $APP_NAME"
    log_info "2. Set up SSL: heroku certs:auto:enable -a $APP_NAME"
    log_info "3. Configure monitoring and alerts"
    log_info "4. Set up CI/CD pipeline"
    log_info "5. Configure database backups (if using database)"
}

# Cleanup
cleanup() {
    log_info "Cleaning up temporary files..."
    # Add any cleanup tasks here
    log_success "Cleanup completed"
}

# Main deployment process
main() {
    log_info "Starting Heroku deployment for $APP_NAME"
    log_info "Timestamp: $(date)"
    
    check_prerequisites
    init_git_repo
    update_package_json
    create_server
    create_procfile
    create_release_script
    install_dependencies
    run_tests
    create_heroku_app
    configure_environment
    add_heroku_addons
    deploy_to_heroku
    scale_dynos
    verify_deployment
    cleanup
    show_post_deployment_info
}

# Handle script interruption
trap cleanup EXIT

# Run main function
main "$@"