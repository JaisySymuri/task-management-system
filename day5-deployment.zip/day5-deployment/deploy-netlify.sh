#!/bin/bash

# Netlify Deployment Script for Task Management System
# This script automates the deployment process to Netlify

set -e

# Configuration
PROJECT_NAME="task-management-system"
BUILD_DIR="dist"
NETLIFY_SITE_ID="${NETLIFY_SITE_ID:-}"
NETLIFY_AUTH_TOKEN="${NETLIFY_AUTH_TOKEN:-}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check if Node.js is installed
    if ! command -v node &> /dev/null; then
        log_error "Node.js is not installed. Please install Node.js first."
        exit 1
    fi
    
    # Check if npm is installed
    if ! command -v npm &> /dev/null; then
        log_error "npm is not installed. Please install npm first."
        exit 1
    fi
    
    # Check if Netlify CLI is installed
    if ! command -v netlify &> /dev/null; then
        log_warning "Netlify CLI is not installed. Installing..."
        npm install -g netlify-cli
    fi
    
    log_success "Prerequisites check completed"
}

# Install dependencies
install_dependencies() {
    log_info "Installing dependencies..."
    
    if [ -f "package-lock.json" ]; then
        npm ci
    else
        npm install
    fi
    
    log_success "Dependencies installed"
}

# Run tests
run_tests() {
    log_info "Running tests..."
    
    if npm run test --if-present; then
        log_success "All tests passed"
    else
        log_error "Tests failed. Deployment aborted."
        exit 1
    fi
}

# Build application
build_application() {
    log_info "Building application..."
    
    # Clean previous build
    rm -rf "$BUILD_DIR"
    
    # Create build directory
    mkdir -p "$BUILD_DIR"
    
    # Copy static files
    cp -r public/* "$BUILD_DIR/"
    
    # Copy source files (for client-side app)
    cp -r src "$BUILD_DIR/"
    
    # Create netlify.toml if it doesn't exist
    if [ ! -f "netlify.toml" ]; then
        log_info "Creating netlify.toml configuration..."
        cat > netlify.toml << EOF
[build]
  publish = "$BUILD_DIR"
  command = "echo 'Static site - no build command needed'"

[build.environment]
  NODE_VERSION = "18"

[[redirects]]
  from = "/api/*"
  to = "/.netlify/functions/:splat"
  status = 200

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200

[dev]
  command = "npm start"
  port = 3000
  publish = "$BUILD_DIR"

[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "DENY"
    X-XSS-Protection = "1; mode=block"
    X-Content-Type-Options = "nosniff"
    Referrer-Policy = "strict-origin-when-cross-origin"

[[headers]]
  for = "/static/*"
  [headers.values]
    Cache-Control = "public, max-age=31536000, immutable"

[[headers]]
  for = "*.js"
  [headers.values]
    Cache-Control = "public, max-age=31536000, immutable"

[[headers]]
  for = "*.css"
  [headers.values]
    Cache-Control = "public, max-age=31536000, immutable"
EOF
    fi
    
    # Create _redirects file for SPA routing
    echo "/*    /index.html   200" > "$BUILD_DIR/_redirects"
    
    # Create _headers file for security
    cat > "$BUILD_DIR/_headers" << EOF
/*
  X-Frame-Options: DENY
  X-XSS-Protection: 1; mode=block
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin

/static/*
  Cache-Control: public, max-age=31536000, immutable

*.js
  Cache-Control: public, max-age=31536000, immutable

*.css
  Cache-Control: public, max-age=31536000, immutable
EOF
    
    log_success "Application built successfully"
}

# Create Netlify functions (if needed)
create_functions() {
    log_info "Creating Netlify functions..."
    
    mkdir -p netlify/functions
    
    # Create a simple API function
    cat > netlify/functions/health.js << 'EOF'
exports.handler = async (event, context) => {
  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE'
    },
    body: JSON.stringify({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      environment: 'netlify',
      version: process.env.npm_package_version || '1.0.0'
    })
  };
};
EOF
    
    # Create a tasks API function
    cat > netlify/functions/tasks.js << 'EOF'
const tasks = [];
let nextId = 1;

exports.handler = async (event, context) => {
  const { httpMethod, path, body } = event;
  
  // CORS headers
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE'
  };
  
  // Handle preflight requests
  if (httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }
  
  try {
    switch (httpMethod) {
      case 'GET':
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify(tasks)
        };
        
      case 'POST':
        const newTask = JSON.parse(body);
        const task = {
          id: nextId++,
          title: newTask.title,
          description: newTask.description || '',
          completed: false,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        tasks.push(task);
        
        return {
          statusCode: 201,
          headers,
          body: JSON.stringify(task)
        };
        
      case 'PUT':
        const taskId = parseInt(path.split('/').pop());
        const updates = JSON.parse(body);
        const taskIndex = tasks.findIndex(t => t.id === taskId);
        
        if (taskIndex === -1) {
          return {
            statusCode: 404,
            headers,
            body: JSON.stringify({ error: 'Task not found' })
          };
        }
        
        tasks[taskIndex] = {
          ...tasks[taskIndex],
          ...updates,
          updatedAt: new Date().toISOString()
        };
        
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify(tasks[taskIndex])
        };
        
      case 'DELETE':
        const deleteId = parseInt(path.split('/').pop());
        const deleteIndex = tasks.findIndex(t => t.id === deleteId);
        
        if (deleteIndex === -1) {
          return {
            statusCode: 404,
            headers,
            body: JSON.stringify({ error: 'Task not found' })
          };
        }
        
        tasks.splice(deleteIndex, 1);
        
        return {
          statusCode: 204,
          headers,
          body: ''
        };
        
      default:
        return {
          statusCode: 405,
          headers,
          body: JSON.stringify({ error: 'Method not allowed' })
        };
    }
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Internal server error' })
    };
  }
};
EOF
    
    log_success "Netlify functions created"
}

# Deploy to Netlify
deploy_to_netlify() {
    log_info "Deploying to Netlify..."
    
    # Check if user is logged in
    if ! netlify status &> /dev/null; then
        log_info "Please log in to Netlify..."
        netlify login
    fi
    
    # Deploy
    if [ -n "$NETLIFY_SITE_ID" ]; then
        log_info "Deploying to existing site: $NETLIFY_SITE_ID"
        netlify deploy --prod --dir="$BUILD_DIR" --site="$NETLIFY_SITE_ID"
    else
        log_info "Creating new site and deploying..."
        netlify deploy --prod --dir="$BUILD_DIR"
    fi
    
    log_success "Deployment completed"
}

# Verify deployment
verify_deployment() {
    log_info "Verifying deployment..."
    
    # Get site URL
    SITE_URL=$(netlify status --json | jq -r '.site.url' 2>/dev/null || echo "")
    
    if [ -n "$SITE_URL" ]; then
        log_info "Site URL: $SITE_URL"
        
        # Test health endpoint
        if curl -f -s "$SITE_URL/.netlify/functions/health" > /dev/null; then
            log_success "Health check passed"
        else
            log_warning "Health check failed - this is normal for static sites"
        fi
        
        # Test main page
        if curl -f -s "$SITE_URL" > /dev/null; then
            log_success "Main page is accessible"
        else
            log_error "Main page is not accessible"
            exit 1
        fi
        
        log_success "Deployment verification completed"
        log_info "Your site is live at: $SITE_URL"
    else
        log_warning "Could not determine site URL"
    fi
}

# Cleanup
cleanup() {
    log_info "Cleaning up temporary files..."
    # Add any cleanup tasks here
    log_success "Cleanup completed"
}

# Main deployment process
main() {
    log_info "Starting Netlify deployment for $PROJECT_NAME"
    log_info "Timestamp: $(date)"
    
    check_prerequisites
    install_dependencies
    run_tests
    build_application
    create_functions
    deploy_to_netlify
    verify_deployment
    cleanup
    
    log_success "🚀 Deployment completed successfully!"
    log_info "Next steps:"
    log_info "1. Configure custom domain (if needed): netlify domains:add yourdomain.com"
    log_info "2. Set up environment variables: netlify env:set KEY=value"
    log_info "3. Configure form handling: https://docs.netlify.com/forms/setup/"
    log_info "4. Set up analytics: https://docs.netlify.com/monitor-sites/analytics/"
}

# Handle script interruption
trap cleanup EXIT

# Run main function
main "$@"