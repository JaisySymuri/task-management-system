# Maintenance and Troubleshooting Guide

## Overview
This guide provides comprehensive instructions for maintaining your Task Management System in production, including regular maintenance tasks, troubleshooting common issues, and ensuring long-term system health.

## Table of Contents
- [Regular Maintenance Tasks](#regular-maintenance-tasks)
- [Security Maintenance](#security-maintenance)
- [Performance Optimization](#performance-optimization)
- [Backup and Recovery](#backup-and-recovery)
- [Troubleshooting Guide](#troubleshooting-guide)
- [Emergency Procedures](#emergency-procedures)
- [Monitoring and Alerts](#monitoring-and-alerts)

## Regular Maintenance Tasks

### Daily Tasks

#### 1. System Health Check
```bash
#!/bin/bash
# daily-health-check.sh

echo "=== Daily Health Check - $(date) ==="

# Check application status
echo "1. Checking application status..."
curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/health
if [ $? -eq 0 ]; then
    echo "✅ Application is responding"
else
    echo "❌ Application is not responding"
    # Send alert
    echo "Application down" | mail -s "ALERT: Application Down" admin@example.com
fi

# Check disk space
echo "2. Checking disk space..."
DISK_USAGE=$(df / | tail -1 | awk '{print $5}' | sed 's/%//')
if [ $DISK_USAGE -gt 85 ]; then
    echo "⚠️ Disk usage is ${DISK_USAGE}% - cleanup needed"
    # Clean up old logs
    find /var/log -name "*.log" -mtime +7 -delete
    find ./logs -name "*.log.*" -mtime +7 -delete
else
    echo "✅ Disk usage is ${DISK_USAGE}% - OK"
fi

# Check memory usage
echo "3. Checking memory usage..."
MEMORY_USAGE=$(free | grep Mem | awk '{printf("%.0f", $3/$2 * 100.0)}')
if [ $MEMORY_USAGE -gt 90 ]; then
    echo "⚠️ Memory usage is ${MEMORY_USAGE}% - restart may be needed"
    # Restart application if memory usage is too high
    pm2 restart task-manager
else
    echo "✅ Memory usage is ${MEMORY_USAGE}% - OK"
fi

# Check error logs
echo "4. Checking for errors in logs..."
ERROR_COUNT=$(grep -c "ERROR\|FATAL" ./logs/app-$(date +%Y-%m-%d).log 2>/dev/null || echo "0")
if [ $ERROR_COUNT -gt 10 ]; then
    echo "⚠️ Found ${ERROR_COUNT} errors in today's logs"
    # Send error summary
    tail -20 ./logs/app-$(date +%Y-%m-%d).log | grep "ERROR\|FATAL" | mail -s "Daily Error Summary" admin@example.com
else
    echo "✅ Error count is ${ERROR_COUNT} - OK"
fi

# Check SSL certificate expiry (if applicable)
if command -v openssl &> /dev/null; then
    echo "5. Checking SSL certificate..."
    CERT_EXPIRY=$(echo | openssl s_client -servername yourdomain.com -connect yourdomain.com:443 2>/dev/null | openssl x509 -noout -dates | grep notAfter | cut -d= -f2)
    EXPIRY_DATE=$(date -d "$CERT_EXPIRY" +%s)
    CURRENT_DATE=$(date +%s)
    DAYS_UNTIL_EXPIRY=$(( ($EXPIRY_DATE - $CURRENT_DATE) / 86400 ))
    
    if [ $DAYS_UNTIL_EXPIRY -lt 30 ]; then
        echo "⚠️ SSL certificate expires in ${DAYS_UNTIL_EXPIRY} days"
    else
        echo "✅ SSL certificate expires in ${DAYS_UNTIL_EXPIRY} days - OK"
    fi
fi

echo "=== Health check completed ==="
```

#### 2. Log Review
```bash
#!/bin/bash
# daily-log-review.sh

LOG_DATE=$(date +%Y-%m-%d)
LOG_FILE="./logs/app-${LOG_DATE}.log"

if [ -f "$LOG_FILE" ]; then
    echo "=== Daily Log Review - $LOG_DATE ==="
    
    # Count log levels
    echo "Log Level Summary:"
    echo "- Errors: $(grep -c '"level":"error"' "$LOG_FILE")"
    echo "- Warnings: $(grep -c '"level":"warn"' "$LOG_FILE")"
    echo "- Info: $(grep -c '"level":"info"' "$LOG_FILE")"
    
    # Show recent errors
    echo -e "\nRecent Errors:"
    grep '"level":"error"' "$LOG_FILE" | tail -5 | jq -r '.timestamp + " - " + .message'
    
    # Show performance metrics
    echo -e "\nPerformance Summary:"
    grep '"duration"' "$LOG_FILE" | jq -r '.duration' | awk '
    {
        sum += $1
        count++
        if ($1 > max) max = $1
        if (min == 0 || $1 < min) min = $1
    }
    END {
        if (count > 0) {
            print "- Average response time: " (sum/count) "ms"
            print "- Max response time: " max "ms"
            print "- Min response time: " min "ms"
            print "- Total requests: " count
        }
    }'
else
    echo "No log file found for $LOG_DATE"
fi
```

### Weekly Tasks

#### 1. Dependency Updates
```bash
#!/bin/bash
# weekly-dependency-check.sh

echo "=== Weekly Dependency Check - $(date) ==="

# Check for outdated packages
echo "1. Checking for outdated packages..."
npm outdated

# Check for security vulnerabilities
echo "2. Running security audit..."
npm audit

# Check for high/critical vulnerabilities
VULNERABILITIES=$(npm audit --json | jq '.metadata.vulnerabilities.high + .metadata.vulnerabilities.critical')
if [ "$VULNERABILITIES" -gt 0 ]; then
    echo "⚠️ Found $VULNERABILITIES high/critical vulnerabilities"
    echo "Run 'npm audit fix' to resolve automatically fixable issues"
    
    # Create backup before updating
    cp package.json package.json.backup
    cp package-lock.json package-lock.json.backup
    
    # Try to fix automatically
    npm audit fix
    
    # Test after fixes
    npm test
    if [ $? -eq 0 ]; then
        echo "✅ Security fixes applied successfully"
        rm package.json.backup package-lock.json.backup
    else
        echo "❌ Tests failed after security fixes - reverting"
        mv package.json.backup package.json
        mv package-lock.json.backup package-lock.json
        npm install
    fi
else
    echo "✅ No high/critical vulnerabilities found"
fi

# Check Node.js version
echo "3. Checking Node.js version..."
CURRENT_NODE=$(node --version)
echo "Current Node.js version: $CURRENT_NODE"

# You can add logic here to check for newer LTS versions
```

#### 2. Performance Review
```bash
#!/bin/bash
# weekly-performance-review.sh

echo "=== Weekly Performance Review - $(date) ==="

# Analyze last 7 days of logs
for i in {0..6}; do
    LOG_DATE=$(date -d "$i days ago" +%Y-%m-%d)
    LOG_FILE="./logs/app-${LOG_DATE}.log"
    
    if [ -f "$LOG_FILE" ]; then
        echo "Analyzing $LOG_DATE..."
        
        # Extract response times
        grep '"duration"' "$LOG_FILE" | jq -r '.duration' > /tmp/response_times_$i.txt
        
        # Calculate statistics
        if [ -s /tmp/response_times_$i.txt ]; then
            AVG=$(awk '{sum+=$1} END {print sum/NR}' /tmp/response_times_$i.txt)
            MAX=$(sort -n /tmp/response_times_$i.txt | tail -1)
            P95=$(sort -n /tmp/response_times_$i.txt | awk '{all[NR] = $0} END{print all[int(NR*0.95)]}')
            
            echo "  - Average: ${AVG}ms, Max: ${MAX}ms, 95th percentile: ${P95}ms"
        fi
        
        rm -f /tmp/response_times_$i.txt
    fi
done

# Check current system performance
echo -e "\nCurrent System Performance:"
echo "- CPU Usage: $(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)%"
echo "- Memory Usage: $(free | grep Mem | awk '{printf("%.1f%%", $3/$2 * 100.0)}')"
echo "- Load Average: $(uptime | awk -F'load average:' '{print $2}')"
```

### Monthly Tasks

#### 1. Full System Backup
```bash
#!/bin/bash
# monthly-backup.sh

BACKUP_DATE=$(date +%Y-%m-%d)
BACKUP_DIR="/backups/monthly"
APP_DIR="/var/www/task-manager"

echo "=== Monthly Backup - $BACKUP_DATE ==="

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Backup application files
echo "1. Backing up application files..."
tar -czf "$BACKUP_DIR/app-backup-$BACKUP_DATE.tar.gz" \
    --exclude="node_modules" \
    --exclude="logs" \
    --exclude="coverage" \
    "$APP_DIR"

# Backup configuration files
echo "2. Backing up configuration files..."
tar -czf "$BACKUP_DIR/config-backup-$BACKUP_DATE.tar.gz" \
    /etc/nginx/sites-available/task-manager \
    /etc/systemd/system/task-manager.service \
    ~/.pm2/dump.pm2 \
    2>/dev/null

# Backup logs (last 30 days)
echo "3. Backing up recent logs..."
find "$APP_DIR/logs" -name "*.log*" -mtime -30 | \
    tar -czf "$BACKUP_DIR/logs-backup-$BACKUP_DATE.tar.gz" -T -

# Backup user data (if stored locally)
echo "4. Backing up user data..."
if [ -d "$APP_DIR/data" ]; then
    tar -czf "$BACKUP_DIR/data-backup-$BACKUP_DATE.tar.gz" "$APP_DIR/data"
fi

# Clean up old backups (keep last 6 months)
echo "5. Cleaning up old backups..."
find "$BACKUP_DIR" -name "*backup*.tar.gz" -mtime +180 -delete

# Verify backups
echo "6. Verifying backups..."
for backup in "$BACKUP_DIR"/*backup-$BACKUP_DATE.tar.gz; do
    if tar -tzf "$backup" >/dev/null 2>&1; then
        echo "✅ $(basename "$backup") - OK"
    else
        echo "❌ $(basename "$backup") - CORRUPTED"
    fi
done

# Upload to cloud storage (optional)
if command -v aws &> /dev/null && [ -n "$AWS_S3_BUCKET" ]; then
    echo "7. Uploading to S3..."
    aws s3 sync "$BACKUP_DIR" "s3://$AWS_S3_BUCKET/backups/monthly/"
fi

echo "=== Backup completed ==="
```

#### 2. Security Review
```bash
#!/bin/bash
# monthly-security-review.sh

echo "=== Monthly Security Review - $(date) ==="

# Check for failed login attempts (if applicable)
echo "1. Checking authentication logs..."
if [ -f "/var/log/auth.log" ]; then
    FAILED_LOGINS=$(grep "Failed password" /var/log/auth.log | wc -l)
    echo "Failed login attempts this month: $FAILED_LOGINS"
    
    if [ $FAILED_LOGINS -gt 100 ]; then
        echo "⚠️ High number of failed login attempts detected"
        # Show top attacking IPs
        grep "Failed password" /var/log/auth.log | \
            awk '{print $(NF-3)}' | sort | uniq -c | sort -nr | head -10
    fi
fi

# Check SSL certificate
echo "2. Checking SSL configuration..."
if command -v nmap &> /dev/null; then
    nmap --script ssl-enum-ciphers -p 443 localhost 2>/dev/null | \
        grep -E "(TLS|SSL|cipher)"
fi

# Check for open ports
echo "3. Checking open ports..."
netstat -tuln | grep LISTEN

# Check file permissions
echo "4. Checking critical file permissions..."
find /etc/ssl -name "*.key" -exec ls -la {} \; 2>/dev/null
ls -la ~/.ssh/ 2>/dev/null

# Check for world-writable files
echo "5. Checking for world-writable files..."
WRITABLE_FILES=$(find /var/www -type f -perm -002 2>/dev/null | wc -l)
if [ $WRITABLE_FILES -gt 0 ]; then
    echo "⚠️ Found $WRITABLE_FILES world-writable files"
    find /var/www -type f -perm -002 2>/dev/null | head -10
fi

# Check system updates
echo "6. Checking for system updates..."
if command -v apt &> /dev/null; then
    apt list --upgradable 2>/dev/null | wc -l
elif command -v yum &> /dev/null; then
    yum check-update | grep -c "updates"
fi

echo "=== Security review completed ==="
```

## Security Maintenance

### SSL Certificate Management

#### Automatic Renewal with Let's Encrypt
```bash
#!/bin/bash
# ssl-renewal-check.sh

echo "=== SSL Certificate Renewal Check ==="

# Check certificate expiry
DOMAIN="yourdomain.com"
EXPIRY_DATE=$(echo | openssl s_client -servername $DOMAIN -connect $DOMAIN:443 2>/dev/null | \
              openssl x509 -noout -dates | grep notAfter | cut -d= -f2)

if [ -n "$EXPIRY_DATE" ]; then
    EXPIRY_TIMESTAMP=$(date -d "$EXPIRY_DATE" +%s)
    CURRENT_TIMESTAMP=$(date +%s)
    DAYS_UNTIL_EXPIRY=$(( ($EXPIRY_TIMESTAMP - $CURRENT_TIMESTAMP) / 86400 ))
    
    echo "Certificate expires in $DAYS_UNTIL_EXPIRY days"
    
    if [ $DAYS_UNTIL_EXPIRY -lt 30 ]; then
        echo "⚠️ Certificate expires soon - attempting renewal"
        
        # Attempt renewal
        certbot renew --quiet
        
        if [ $? -eq 0 ]; then
            echo "✅ Certificate renewed successfully"
            systemctl reload nginx
        else
            echo "❌ Certificate renewal failed"
            # Send alert
            echo "SSL certificate renewal failed for $DOMAIN" | \
                mail -s "ALERT: SSL Renewal Failed" admin@example.com
        fi
    else
        echo "✅ Certificate is valid"
    fi
else
    echo "❌ Could not check certificate expiry"
fi
```

### Security Headers Verification
```bash
#!/bin/bash
# security-headers-check.sh

DOMAIN="https://yourdomain.com"

echo "=== Security Headers Check ==="

# Check security headers
curl -s -I "$DOMAIN" | grep -i -E "(strict-transport|content-security|x-frame|x-content-type|x-xss)"

# Use online tool for comprehensive check
echo -e "\nFor comprehensive security analysis, visit:"
echo "https://securityheaders.com/?q=$DOMAIN"
echo "https://observatory.mozilla.org/analyze/$DOMAIN"
```

## Performance Optimization

### Database Optimization (for localStorage-based app)
```javascript
// storage-optimization.js
class StorageOptimizer {
    constructor() {
        this.compressionEnabled = true;
        this.cleanupInterval = 24 * 60 * 60 * 1000; // 24 hours
        this.maxStorageSize = 5 * 1024 * 1024; // 5MB
        
        this.startCleanupSchedule();
    }

    startCleanupSchedule() {
        setInterval(() => {
            this.performCleanup();
        }, this.cleanupInterval);
    }

    performCleanup() {
        console.log('Starting storage cleanup...');
        
        // Remove expired items
        this.removeExpiredItems();
        
        // Compress data if needed
        if (this.compressionEnabled) {
            this.compressStorageData();
        }
        
        // Check storage size
        this.checkStorageSize();
        
        console.log('Storage cleanup completed');
    }

    removeExpiredItems() {
        const now = Date.now();
        const keysToRemove = [];
        
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && key.startsWith('temp_')) {
                try {
                    const item = JSON.parse(localStorage.getItem(key));
                    if (item.expiry && item.expiry < now) {
                        keysToRemove.push(key);
                    }
                } catch (error) {
                    // Invalid JSON, remove it
                    keysToRemove.push(key);
                }
            }
        }
        
        keysToRemove.forEach(key => {
            localStorage.removeItem(key);
            console.log(`Removed expired item: ${key}`);
        });
    }

    compressStorageData() {
        // Simple compression for large data items
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && key.startsWith('tasks_')) {
                const data = localStorage.getItem(key);
                if (data && data.length > 1000) {
                    try {
                        // Simple compression by removing whitespace
                        const compressed = JSON.stringify(JSON.parse(data));
                        if (compressed.length < data.length) {
                            localStorage.setItem(key, compressed);
                            console.log(`Compressed ${key}: ${data.length} -> ${compressed.length} bytes`);
                        }
                    } catch (error) {
                        console.error(`Failed to compress ${key}:`, error);
                    }
                }
            }
        }
    }

    checkStorageSize() {
        let totalSize = 0;
        
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key) {
                totalSize += localStorage.getItem(key).length;
            }
        }
        
        console.log(`Total storage size: ${(totalSize / 1024).toFixed(2)} KB`);
        
        if (totalSize > this.maxStorageSize) {
            console.warn('Storage size exceeds limit, cleaning up old data...');
            this.cleanupOldData();
        }
    }

    cleanupOldData() {
        // Remove oldest non-essential data
        const items = [];
        
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && !key.startsWith('user_') && !key.startsWith('settings_')) {
                try {
                    const item = JSON.parse(localStorage.getItem(key));
                    if (item.timestamp) {
                        items.push({ key, timestamp: item.timestamp });
                    }
                } catch (error) {
                    // Remove invalid items
                    localStorage.removeItem(key);
                }
            }
        }
        
        // Sort by timestamp and remove oldest 20%
        items.sort((a, b) => a.timestamp - b.timestamp);
        const toRemove = Math.ceil(items.length * 0.2);
        
        for (let i = 0; i < toRemove; i++) {
            localStorage.removeItem(items[i].key);
            console.log(`Removed old data: ${items[i].key}`);
        }
    }

    getStorageStats() {
        let totalSize = 0;
        let itemCount = 0;
        const categories = {};
        
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key) {
                const size = localStorage.getItem(key).length;
                totalSize += size;
                itemCount++;
                
                const category = key.split('_')[0] || 'other';
                categories[category] = (categories[category] || 0) + size;
            }
        }
        
        return {
            totalSize: totalSize,
            totalSizeKB: (totalSize / 1024).toFixed(2),
            itemCount: itemCount,
            categories: categories,
            percentUsed: ((totalSize / this.maxStorageSize) * 100).toFixed(2)
        };
    }
}

// Initialize storage optimizer
const storageOptimizer = new StorageOptimizer();

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = StorageOptimizer;
}
```

### Application Performance Monitoring
```javascript
// performance-optimizer.js
class PerformanceOptimizer {
    constructor() {
        this.metrics = {
            renderTimes: [],
            apiCalls: [],
            memoryUsage: [],
            userInteractions: []
        };
        
        this.setupPerformanceMonitoring();
    }

    setupPerformanceMonitoring() {
        // Monitor render performance
        this.monitorRenderPerformance();
        
        // Monitor API calls
        this.monitorApiCalls();
        
        // Monitor memory usage
        this.monitorMemoryUsage();
        
        // Monitor user interactions
        this.monitorUserInteractions();
    }

    monitorRenderPerformance() {
        // Override common DOM methods to measure performance
        const originalAppendChild = Element.prototype.appendChild;
        const originalRemoveChild = Element.prototype.removeChild;
        
        Element.prototype.appendChild = function(child) {
            const start = performance.now();
            const result = originalAppendChild.call(this, child);
            const duration = performance.now() - start;
            
            if (duration > 16) { // More than one frame (60fps)
                console.warn(`Slow DOM operation: appendChild took ${duration.toFixed(2)}ms`);
            }
            
            return result;
        };
        
        Element.prototype.removeChild = function(child) {
            const start = performance.now();
            const result = originalRemoveChild.call(this, child);
            const duration = performance.now() - start;
            
            if (duration > 16) {
                console.warn(`Slow DOM operation: removeChild took ${duration.toFixed(2)}ms`);
            }
            
            return result;
        };
    }

    monitorApiCalls() {
        const originalFetch = window.fetch;
        
        window.fetch = async (...args) => {
            const start = performance.now();
            const url = args[0];
            
            try {
                const response = await originalFetch(...args);
                const duration = performance.now() - start;
                
                this.metrics.apiCalls.push({
                    url: url,
                    duration: duration,
                    status: response.status,
                    timestamp: Date.now()
                });
                
                if (duration > 2000) {
                    console.warn(`Slow API call: ${url} took ${duration.toFixed(2)}ms`);
                }
                
                return response;
            } catch (error) {
                const duration = performance.now() - start;
                
                this.metrics.apiCalls.push({
                    url: url,
                    duration: duration,
                    error: error.message,
                    timestamp: Date.now()
                });
                
                throw error;
            }
        };
    }

    monitorMemoryUsage() {
        if (performance.memory) {
            setInterval(() => {
                const memory = performance.memory;
                this.metrics.memoryUsage.push({
                    used: memory.usedJSHeapSize,
                    total: memory.totalJSHeapSize,
                    limit: memory.jsHeapSizeLimit,
                    timestamp: Date.now()
                });
                
                // Keep only last 100 measurements
                if (this.metrics.memoryUsage.length > 100) {
                    this.metrics.memoryUsage.shift();
                }
                
                // Warn if memory usage is high
                const usagePercent = (memory.usedJSHeapSize / memory.jsHeapSizeLimit) * 100;
                if (usagePercent > 90) {
                    console.warn(`High memory usage: ${usagePercent.toFixed(2)}%`);
                }
            }, 30000); // Every 30 seconds
        }
    }

    monitorUserInteractions() {
        ['click', 'keydown', 'scroll'].forEach(eventType => {
            document.addEventListener(eventType, (event) => {
                const start = performance.now();
                
                // Use requestAnimationFrame to measure until next frame
                requestAnimationFrame(() => {
                    const duration = performance.now() - start;
                    
                    this.metrics.userInteractions.push({
                        type: eventType,
                        target: event.target.tagName,
                        duration: duration,
                        timestamp: Date.now()
                    });
                    
                    if (duration > 100) {
                        console.warn(`Slow interaction: ${eventType} took ${duration.toFixed(2)}ms`);
                    }
                });
            }, { passive: true });
        });
    }

    getPerformanceReport() {
        const now = Date.now();
        const oneHourAgo = now - 3600000;
        
        // Filter recent metrics
        const recentApiCalls = this.metrics.apiCalls.filter(call => call.timestamp > oneHourAgo);
        const recentInteractions = this.metrics.userInteractions.filter(interaction => interaction.timestamp > oneHourAgo);
        
        return {
            apiCalls: {
                total: recentApiCalls.length,
                averageTime: recentApiCalls.reduce((sum, call) => sum + call.duration, 0) / recentApiCalls.length || 0,
                slowCalls: recentApiCalls.filter(call => call.duration > 2000).length,
                errors: recentApiCalls.filter(call => call.error).length
            },
            userInteractions: {
                total: recentInteractions.length,
                averageTime: recentInteractions.reduce((sum, interaction) => sum + interaction.duration, 0) / recentInteractions.length || 0,
                slowInteractions: recentInteractions.filter(interaction => interaction.duration > 100).length
            },
            memory: this.metrics.memoryUsage.length > 0 ? {
                current: this.metrics.memoryUsage[this.metrics.memoryUsage.length - 1],
                peak: Math.max(...this.metrics.memoryUsage.map(m => m.used)),
                average: this.metrics.memoryUsage.reduce((sum, m) => sum + m.used, 0) / this.metrics.memoryUsage.length
            } : null
        };
    }

    optimizePerformance() {
        console.log('Running performance optimizations...');
        
        // Clean up old metrics
        const oneHourAgo = Date.now() - 3600000;
        this.metrics.apiCalls = this.metrics.apiCalls.filter(call => call.timestamp > oneHourAgo);
        this.metrics.userInteractions = this.metrics.userInteractions.filter(interaction => interaction.timestamp > oneHourAgo);
        
        // Force garbage collection if available
        if (window.gc) {
            window.gc();
        }
        
        // Optimize DOM
        this.optimizeDOM();
        
        console.log('Performance optimizations completed');
    }

    optimizeDOM() {
        // Remove unused event listeners
        const elements = document.querySelectorAll('*');
        elements.forEach(element => {
            // Remove elements that are not visible and have no children
            if (element.offsetParent === null && element.children.length === 0 && element.textContent.trim() === '') {
                element.remove();
            }
        });
        
        // Clean up inline styles that match CSS rules
        const elementsWithStyle = document.querySelectorAll('[style]');
        elementsWithStyle.forEach(element => {
            const computedStyle = window.getComputedStyle(element);
            const inlineStyle = element.style;
            
            // Remove redundant inline styles
            for (let i = inlineStyle.length - 1; i >= 0; i--) {
                const property = inlineStyle[i];
                const inlineValue = inlineStyle.getPropertyValue(property);
                const computedValue = computedStyle.getPropertyValue(property);
                
                if (inlineValue === computedValue) {
                    inlineStyle.removeProperty(property);
                }
            }
            
            // Remove empty style attribute
            if (inlineStyle.length === 0) {
                element.removeAttribute('style');
            }
        });
    }
}

// Initialize performance optimizer
const performanceOptimizer = new PerformanceOptimizer();

// Run optimization every 5 minutes
setInterval(() => {
    performanceOptimizer.optimizePerformance();
}, 300000);

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PerformanceOptimizer;
}
```

## Backup and Recovery

### Automated Backup System
```bash
#!/bin/bash
# automated-backup-system.sh

# Configuration
BACKUP_ROOT="/backups"
APP_DIR="/var/www/task-manager"
RETENTION_DAYS=30
S3_BUCKET="your-backup-bucket"
ENCRYPTION_KEY="/etc/backup/backup.key"

# Create backup directories
mkdir -p "$BACKUP_ROOT"/{daily,weekly,monthly}

# Generate encryption key if it doesn't exist
if [ ! -f "$ENCRYPTION_KEY" ]; then
    mkdir -p "$(dirname "$ENCRYPTION_KEY")"
    openssl rand -base64 32 > "$ENCRYPTION_KEY"
    chmod 600 "$ENCRYPTION_KEY"
fi

backup_and_encrypt() {
    local source="$1"
    local destination="$2"
    local name="$3"
    
    echo "Backing up $name..."
    
    # Create compressed backup
    tar -czf - "$source" | \
    openssl enc -aes-256-cbc -salt -pass file:"$ENCRYPTION_KEY" > "$destination"
    
    if [ $? -eq 0 ]; then
        echo "✅ $name backup completed: $(basename "$destination")"
        return 0
    else
        echo "❌ $name backup failed"
        return 1
    fi
}

verify_backup() {
    local backup_file="$1"
    local name="$2"
    
    echo "Verifying $name backup..."
    
    # Test decryption and archive integrity
    openssl enc -aes-256-cbc -d -pass file:"$ENCRYPTION_KEY" -in "$backup_file" | \
    tar -tzf - >/dev/null 2>&1
    
    if [ $? -eq 0 ]; then
        echo "✅ $name backup verification passed"
        return 0
    else
        echo "❌ $name backup verification failed"
        return 1
    fi
}

# Daily backup
daily_backup() {
    local date=$(date +%Y-%m-%d)
    local backup_dir="$BACKUP_ROOT/daily"
    
    echo "=== Daily Backup - $date ==="
    
    # Application files
    backup_and_encrypt "$APP_DIR" "$backup_dir/app-$date.tar.gz.enc" "Application"
    verify_backup "$backup_dir/app-$date.tar.gz.enc" "Application"
    
    # Configuration files
    backup_and_encrypt "/etc/nginx/sites-available" "$backup_dir/nginx-$date.tar.gz.enc" "Nginx Config"
    
    # Logs (last 7 days)
    find "$APP_DIR/logs" -name "*.log*" -mtime -7 | \
    tar -czf - -T - | \
    openssl enc -aes-256-cbc -salt -pass file:"$ENCRYPTION_KEY" > "$backup_dir/logs-$date.tar.gz.enc"
    
    # Clean up old daily backups
    find "$backup_dir" -name "*.tar.gz.enc" -mtime +7 -delete
    
    echo "Daily backup completed"
}

# Weekly backup
weekly_backup() {
    local week=$(date +%Y-W%U)
    local backup_dir="$BACKUP_ROOT/weekly"
    
    echo "=== Weekly Backup - $week ==="
    
    # Full system backup
    backup_and_encrypt "$APP_DIR" "$backup_dir/full-$week.tar.gz.enc" "Full System"
    verify_backup "$backup_dir/full-$week.tar.gz.enc" "Full System"
    
    # Database backup (if applicable)
    # mysqldump --all-databases | gzip | \
    # openssl enc -aes-256-cbc -salt -pass file:"$ENCRYPTION_KEY" > "$backup_dir/db-$week.sql.gz.enc"
    
    # Clean up old weekly backups
    find "$backup_dir" -name "*.tar.gz.enc" -mtime +28 -delete
    
    echo "Weekly backup completed"
}

# Monthly backup
monthly_backup() {
    local month=$(date +%Y-%m)
    local backup_dir="$BACKUP_ROOT/monthly"
    
    echo "=== Monthly Backup - $month ==="
    
    # Archive backup
    backup_and_encrypt "$APP_DIR" "$backup_dir/archive-$month.tar.gz.enc" "Monthly Archive"
    verify_backup "$backup_dir/archive-$month.tar.gz.enc" "Monthly Archive"
    
    # Clean up old monthly backups (keep 12 months)
    find "$backup_dir" -name "*.tar.gz.enc" -mtime +365 -delete
    
    echo "Monthly backup completed"
}

# Upload to cloud storage
upload_to_cloud() {
    if command -v aws &> /dev/null && [ -n "$S3_BUCKET" ]; then
        echo "Uploading backups to S3..."
        
        aws s3 sync "$BACKUP_ROOT" "s3://$S3_BUCKET/backups/" \
            --exclude "*" \
            --include "*.tar.gz.enc" \
            --storage-class STANDARD_IA
        
        if [ $? -eq 0 ]; then
            echo "✅ Cloud upload completed"
        else
            echo "❌ Cloud upload failed"
        fi
    fi
}

# Recovery function
restore_backup() {
    local backup_file="$1"
    local restore_dir="$2"
    
    if [ ! -f "$backup_file" ]; then
        echo "❌ Backup file not found: $backup_file"
        return 1
    fi
    
    echo "Restoring from backup: $backup_file"
    echo "Restore directory: $restore_dir"
    
    # Create restore directory
    mkdir -p "$restore_dir"
    
    # Decrypt and extract
    openssl enc -aes-256-cbc -d -pass file:"$ENCRYPTION_KEY" -in "$backup_file" | \
    tar -xzf - -C "$restore_dir"
    
    if [ $? -eq 0 ]; then
        echo "✅ Restore completed successfully"
        return 0
    else
        echo "❌ Restore failed"
        return 1
    fi
}

# Main execution
case "${1:-daily}" in
    "daily")
        daily_backup
        upload_to_cloud
        ;;
    "weekly")
        weekly_backup
        upload_to_cloud
        ;;
    "monthly")
        monthly_backup
        upload_to_cloud
        ;;
    "restore")
        if [ -z "$2" ] || [ -z "$3" ]; then
            echo "Usage: $0 restore <backup_file> <restore_directory>"
            exit 1
        fi
        restore_backup "$2" "$3"
        ;;
    *)
        echo "Usage: $0 {daily|weekly|monthly|restore}"
        exit 1
        ;;
esac
```

## Troubleshooting Guide

### Common Issues and Solutions

#### 1. Application Won't Start
```bash
# Check if port is in use
sudo lsof -i :3000

# Check application logs
tail -f ./logs/app-$(date +%Y-%m-%d).log

# Check PM2 status
pm2 status
pm2 logs task-manager

# Restart application
pm2 restart task-manager

# If PM2 is not responding
pm2 kill
pm2 start server.js --name task-manager
```

#### 2. High Memory Usage
```bash
# Check memory usage
free -h
ps aux --sort=-%mem | head -10

# Check for memory leaks in Node.js
node --inspect server.js
# Then connect Chrome DevTools to inspect memory

# Restart application to free memory
pm2 restart task-manager

# Check for large log files
du -sh ./logs/*
find ./logs -name "*.log" -size +100M
```

#### 3. Slow Performance
```bash
# Check CPU usage
top -p $(pgrep -f "task-manager")

# Check disk I/O
iotop

# Check network connections
netstat -tuln | grep :3000

# Profile application
node --prof server.js
# After running for a while, stop and analyze
node --prof-process isolate-*.log > profile.txt
```

#### 4. Database/Storage Issues
```javascript
// storage-diagnostics.js
function diagnoseStorageIssues() {
    console.log('=== Storage Diagnostics ===');
    
    // Check localStorage availability
    try {
        const testKey = '__storage_test__';
        localStorage.setItem(testKey, 'test');
        localStorage.removeItem(testKey);
        console.log('✅ localStorage is available');
    } catch (error) {
        console.error('❌ localStorage is not available:', error.message);
        return;
    }
    
    // Check storage usage
    let totalSize = 0;
    let itemCount = 0;
    const largeItems = [];
    
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key) {
            const value = localStorage.getItem(key);
            const size = value.length;
            totalSize += size;
            itemCount++;
            
            if (size > 10000) { // Items larger than 10KB
                largeItems.push({ key, size });
            }
        }
    }
    
    console.log(`Total items: ${itemCount}`);
    console.log(`Total size: ${(totalSize / 1024).toFixed(2)} KB`);
    console.log(`Average item size: ${(totalSize / itemCount / 1024).toFixed(2)} KB`);
    
    if (largeItems.length > 0) {
        console.log('Large items:');
        largeItems.forEach(item => {
            console.log(`  ${item.key}: ${(item.size / 1024).toFixed(2)} KB`);
        });
    }
    
    // Check for corrupted data
    let corruptedItems = 0;
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key) {
            try {
                const value = localStorage.getItem(key);
                if (key.startsWith('tasks_') || key.startsWith('user_')) {
                    JSON.parse(value); // Validate JSON
                }
            } catch (error) {
                console.error(`❌ Corrupted item: ${key}`);
                corruptedItems++;
            }
        }
    }
    
    if (corruptedItems > 0) {
        console.warn(`Found ${corruptedItems} corrupted items`);
    } else {
        console.log('✅ No corrupted items found');
    }
    
    // Check storage quota
    if ('storage' in navigator && 'estimate' in navigator.storage) {
        navigator.storage.estimate().then(estimate => {
            const usedMB = (estimate.usage / 1024 / 1024).toFixed(2);
            const quotaMB = (estimate.quota / 1024 / 1024).toFixed(2);
            const usedPercent = ((estimate.usage / estimate.quota) * 100).toFixed(2);
            
            console.log(`Storage quota: ${quotaMB} MB`);
            console.log(`Storage used: ${usedMB} MB (${usedPercent}%)`);
            
            if (usedPercent > 80) {
                console.warn('⚠️ Storage usage is high');
            }
        });
    }
}

// Run diagnostics
diagnoseStorageIssues();
```

#### 5. Network Issues
```bash
# Test connectivity
curl -I http://localhost:3000/health

# Check DNS resolution
nslookup yourdomain.com

# Check SSL certificate
openssl s_client -connect yourdomain.com:443 -servername yourdomain.com

# Check firewall rules
sudo ufw status
sudo iptables -L

# Check nginx configuration
sudo nginx -t
sudo systemctl status nginx
```

## Emergency Procedures

### Service Recovery Checklist

#### 1. Complete Service Outage
```bash
#!/bin/bash
# emergency-recovery.sh

echo "=== EMERGENCY RECOVERY PROCEDURE ==="
echo "Starting at: $(date)"

# Step 1: Check system status
echo "1. Checking system status..."
systemctl status nginx
systemctl status task-manager 2>/dev/null || pm2 status

# Step 2: Check disk space
echo "2. Checking disk space..."
df -h
if [ $(df / | tail -1 | awk '{print $5}' | sed 's/%//') -gt 95 ]; then
    echo "⚠️ Disk space critical - cleaning up"
    # Emergency cleanup
    find /tmp -type f -mtime +1 -delete
    find ./logs -name "*.log.*" -mtime +3 -delete
    docker system prune -f 2>/dev/null || true
fi

# Step 3: Check memory
echo "3. Checking memory..."
free -h
if [ $(free | grep Mem | awk '{printf("%.0f", $3/$2 * 100.0)}') -gt 95 ]; then
    echo "⚠️ Memory usage critical - restarting services"
    pm2 restart all
fi

# Step 4: Restart services
echo "4. Restarting services..."
sudo systemctl restart nginx
pm2 restart task-manager

# Step 5: Verify recovery
echo "5. Verifying recovery..."
sleep 10
curl -f http://localhost:3000/health
if [ $? -eq 0 ]; then
    echo "✅ Service recovered successfully"
else
    echo "❌ Service recovery failed - escalating"
    # Send emergency alert
    echo "EMERGENCY: Service recovery failed" | mail -s "CRITICAL ALERT" admin@example.com
fi

echo "Recovery procedure completed at: $(date)"
```

#### 2. Data Corruption Recovery
```bash
#!/bin/bash
# data-recovery.sh

echo "=== DATA RECOVERY PROCEDURE ==="

# Step 1: Stop application
echo "1. Stopping application..."
pm2 stop task-manager

# Step 2: Backup current state
echo "2. Backing up current state..."
RECOVERY_DIR="/tmp/recovery-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$RECOVERY_DIR"
cp -r "$APP_DIR/data" "$RECOVERY_DIR/corrupted-data" 2>/dev/null || true

# Step 3: Find latest good backup
echo "3. Finding latest backup..."
LATEST_BACKUP=$(find /backups -name "*.tar.gz.enc" -mtime -7 | sort | tail -1)
if [ -z "$LATEST_BACKUP" ]; then
    echo "❌ No recent backup found"
    exit 1
fi

echo "Using backup: $LATEST_BACKUP"

# Step 4: Restore from backup
echo "4. Restoring from backup..."
cd "$RECOVERY_DIR"
openssl enc -aes-256-cbc -d -pass file:/etc/backup/backup.key -in "$LATEST_BACKUP" | tar -xzf -

if [ $? -eq 0 ]; then
    echo "✅ Backup extracted successfully"
    
    # Step 5: Restore data
    echo "5. Restoring data..."
    cp -r "$RECOVERY_DIR/var/www/task-manager/data"/* "$APP_DIR/data/" 2>/dev/null || true
    
    # Step 6: Restart application
    echo "6. Restarting application..."
    pm2 start task-manager
    
    # Step 7: Verify recovery
    sleep 5
    curl -f http://localhost:3000/health
    if [ $? -eq 0 ]; then
        echo "✅ Data recovery completed successfully"
    else
        echo "❌ Application failed to start after recovery"
    fi
else
    echo "❌ Failed to extract backup"
    exit 1
fi
```

### Contact Information and Escalation

```bash
# emergency-contacts.sh
echo "=== EMERGENCY CONTACTS ==="
echo "Primary Admin: admin@example.com"
echo "Secondary Admin: backup-admin@example.com"
echo "Emergency Phone: +1-555-0123"
echo "Hosting Provider: support@hostingprovider.com"
echo "Domain Registrar: support@domainregistrar.com"
echo ""
echo "=== ESCALATION PROCEDURE ==="
echo "1. Check monitoring dashboard"
echo "2. Run automated recovery scripts"
echo "3. Contact primary admin if recovery fails"
echo "4. Contact secondary admin if primary unavailable"
echo "5. Contact hosting provider for infrastructure issues"
echo "6. Update status page: https://status.yourdomain.com"
```

This comprehensive maintenance and troubleshooting guide provides the foundation for keeping your Task Management System running smoothly in production. Regular execution of these maintenance tasks and familiarity with the troubleshooting procedures will help ensure high availability and performance.