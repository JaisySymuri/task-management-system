# Docker Deployment Guide

## Overview
This guide provides comprehensive instructions for deploying the Task Management System using Docker containers. Docker ensures consistent environments across development, staging, and production.

## Table of Contents
- [Prerequisites](#prerequisites)
- [Docker Setup](#docker-setup)
- [Container Configuration](#container-configuration)
- [Docker Compose](#docker-compose)
- [Production Deployment](#production-deployment)
- [Monitoring and Logging](#monitoring-and-logging)
- [Troubleshooting](#troubleshooting)

## Prerequisites

### System Requirements
- Docker Engine 20.10+
- Docker Compose 2.0+
- Minimum 2GB RAM
- Minimum 10GB disk space

### Installation

#### Ubuntu/Debian
```bash
# Update package index
sudo apt update

# Install dependencies
sudo apt install apt-transport-https ca-certificates curl gnupg lsb-release

# Add Docker's official GPG key
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

# Add Docker repository
echo "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Install Docker
sudo apt update
sudo apt install docker-ce docker-ce-cli containerd.io docker-compose-plugin

# Add user to docker group
sudo usermod -aG docker $USER
newgrp docker

# Verify installation
docker --version
docker compose version
```

#### CentOS/RHEL
```bash
# Install Docker
sudo yum install -y yum-utils
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
sudo yum install docker-ce docker-ce-cli containerd.io docker-compose-plugin

# Start Docker service
sudo systemctl start docker
sudo systemctl enable docker

# Add user to docker group
sudo usermod -aG docker $USER
```

## Docker Setup

### Dockerfile
```dockerfile
# Multi-stage build for production optimization
FROM node:18-alpine AS builder

# Set working directory
WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production && npm cache clean --force

# Copy source code
COPY . .

# Build application (if you have a build step)
RUN npm run build 2>/dev/null || echo "No build step defined"

# Production stage
FROM node:18-alpine AS production

# Create app user for security
RUN addgroup -g 1001 -S nodejs && \
    adduser -S nextjs -u 1001

# Set working directory
WORKDIR /app

# Copy built application from builder stage
COPY --from=builder --chown=nextjs:nodejs /app/node_modules ./node_modules
COPY --from=builder --chown=nextjs:nodejs /app/package*.json ./
COPY --from=builder --chown=nextjs:nodejs /app/server.js ./
COPY --from=builder --chown=nextjs:nodejs /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/src ./src

# Create logs directory
RUN mkdir -p logs && chown nextjs:nodejs logs

# Install dumb-init for proper signal handling
RUN apk add --no-cache dumb-init

# Switch to non-root user
USER nextjs

# Expose port
EXPOSE 3000

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
    CMD node -e "require('http').get('http://localhost:3000/health', (res) => { process.exit(res.statusCode === 200 ? 0 : 1) })"

# Use dumb-init to handle signals properly
ENTRYPOINT ["dumb-init", "--"]

# Start the application
CMD ["node", "server.js"]
```

### .dockerignore
```
# Dependencies
node_modules
npm-debug.log*

# Runtime data
pids
*.pid
*.seed
*.pid.lock

# Coverage directory used by tools like istanbul
coverage
.nyc_output

# Grunt intermediate storage
.grunt

# Bower dependency directory
bower_components

# node-waf configuration
.lock-wscript

# Compiled binary addons
build/Release

# Dependency directories
jspm_packages/

# Optional npm cache directory
.npm

# Optional REPL history
.node_repl_history

# Output of 'npm pack'
*.tgz

# Yarn Integrity file
.yarn-integrity

# dotenv environment variables file
.env
.env.local
.env.development.local
.env.test.local
.env.production.local

# Runtime logs
logs
*.log

# Git
.git
.gitignore

# Docker
Dockerfile*
docker-compose*
.dockerignore

# Documentation
README.md
docs/

# IDE
.vscode
.idea
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Testing
coverage/
.jest/
test-results/

# Build artifacts
dist/
build/
```

### Build and Run Commands
```bash
# Build the Docker image
docker build -t task-manager:latest .

# Run the container
docker run -d \
  --name task-manager \
  -p 3000:3000 \
  -e NODE_ENV=production \
  -e PORT=3000 \
  --restart unless-stopped \
  task-manager:latest

# View logs
docker logs -f task-manager

# Stop and remove container
docker stop task-manager
docker rm task-manager
```

## Container Configuration

### Environment Variables
```bash
# .env.production
NODE_ENV=production
PORT=3000
HOST=0.0.0.0

# Security
SESSION_SECRET=your-secure-session-secret-here
CORS_ORIGINS=https://yourdomain.com,https://www.yourdomain.com

# Monitoring
HEALTH_CHECK_PATH=/health
METRICS_PATH=/metrics

# Logging
LOG_LEVEL=info
LOG_FORMAT=json

# Performance
COMPRESSION_ENABLED=true
CACHE_MAX_AGE=86400

# Rate limiting
RATE_LIMIT_WINDOW=900000
RATE_LIMIT_MAX=100
```

### Volume Mounts
```bash
# Create persistent volumes for data and logs
docker volume create task-manager-data
docker volume create task-manager-logs

# Run with volumes
docker run -d \
  --name task-manager \
  -p 3000:3000 \
  -v task-manager-data:/app/data \
  -v task-manager-logs:/app/logs \
  --env-file .env.production \
  --restart unless-stopped \
  task-manager:latest
```

## Docker Compose

### Basic docker-compose.yml
```yaml
version: '3.8'

services:
  app:
    build:
      context: .
      dockerfile: Dockerfile
      target: production
    container_name: task-manager
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - PORT=3000
      - HOST=0.0.0.0
    env_file:
      - .env.production
    volumes:
      - app-data:/app/data
      - app-logs:/app/logs
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "node", "-e", "require('http').get('http://localhost:3000/health', (res) => { process.exit(res.statusCode === 200 ? 0 : 1) })"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s
    networks:
      - app-network

  nginx:
    image: nginx:alpine
    container_name: task-manager-nginx
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./ssl:/etc/nginx/ssl:ro
      - nginx-logs:/var/log/nginx
    depends_on:
      - app
    restart: unless-stopped
    networks:
      - app-network

volumes:
  app-data:
    driver: local
  app-logs:
    driver: local
  nginx-logs:
    driver: local

networks:
  app-network:
    driver: bridge
```

### Production docker-compose.yml
```yaml
version: '3.8'

services:
  app:
    build:
      context: .
      dockerfile: Dockerfile
      target: production
    container_name: task-manager-app
    expose:
      - "3000"
    environment:
      - NODE_ENV=production
      - PORT=3000
      - HOST=0.0.0.0
    env_file:
      - .env.production
    volumes:
      - app-data:/app/data
      - app-logs:/app/logs
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "node", "-e", "require('http').get('http://localhost:3000/health', (res) => { process.exit(res.statusCode === 200 ? 0 : 1) })"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s
    networks:
      - app-network
    deploy:
      resources:
        limits:
          memory: 512M
          cpus: '0.5'
        reservations:
          memory: 256M
          cpus: '0.25'

  nginx:
    image: nginx:alpine
    container_name: task-manager-nginx
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./nginx/conf.d:/etc/nginx/conf.d:ro
      - ./ssl:/etc/nginx/ssl:ro
      - nginx-logs:/var/log/nginx
    depends_on:
      app:
        condition: service_healthy
    restart: unless-stopped
    networks:
      - app-network
    deploy:
      resources:
        limits:
          memory: 128M
          cpus: '0.25'

  redis:
    image: redis:alpine
    container_name: task-manager-redis
    command: redis-server --appendonly yes --requirepass ${REDIS_PASSWORD}
    volumes:
      - redis-data:/data
    restart: unless-stopped
    networks:
      - app-network
    deploy:
      resources:
        limits:
          memory: 128M
          cpus: '0.25'

  monitoring:
    image: prom/prometheus:latest
    container_name: task-manager-monitoring
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml:ro
      - prometheus-data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'
      - '--web.enable-lifecycle'
    restart: unless-stopped
    networks:
      - app-network

volumes:
  app-data:
    driver: local
  app-logs:
    driver: local
  nginx-logs:
    driver: local
  redis-data:
    driver: local
  prometheus-data:
    driver: local

networks:
  app-network:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/16
```

### Nginx Configuration
```nginx
# nginx/nginx.conf
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
    use epoll;
    multi_accept on;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    # Logging format
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for" '
                    'rt=$request_time uct="$upstream_connect_time" '
                    'uht="$upstream_header_time" urt="$upstream_response_time"';

    access_log /var/log/nginx/access.log main;

    # Performance settings
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    client_max_body_size 10M;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/json
        application/javascript
        application/xml+rss
        application/atom+xml
        image/svg+xml;

    # Security headers
    add_header X-Frame-Options DENY always;
    add_header X-Content-Type-Options nosniff always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Rate limiting
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone $binary_remote_addr zone=login:10m rate=1r/s;

    # Upstream configuration
    upstream app {
        server app:3000;
        keepalive 32;
    }

    # HTTP server (redirect to HTTPS)
    server {
        listen 80;
        server_name _;
        return 301 https://$host$request_uri;
    }

    # HTTPS server
    server {
        listen 443 ssl http2;
        server_name yourdomain.com www.yourdomain.com;

        # SSL configuration
        ssl_certificate /etc/nginx/ssl/cert.pem;
        ssl_certificate_key /etc/nginx/ssl/key.pem;
        ssl_protocols TLSv1.2 TLSv1.3;
        ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384;
        ssl_prefer_server_ciphers off;
        ssl_session_cache shared:SSL:10m;
        ssl_session_timeout 10m;

        # Security headers
        add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

        # Static files
        location /static/ {
            alias /app/public/;
            expires 1y;
            add_header Cache-Control "public, immutable";
        }

        # API endpoints with rate limiting
        location /api/ {
            limit_req zone=api burst=20 nodelay;
            proxy_pass http://app;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;
        }

        # Health check endpoint
        location /health {
            proxy_pass http://app;
            access_log off;
        }

        # Main application
        location / {
            proxy_pass http://app;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;
        }
    }
}
```

## Production Deployment

### Deployment Script
```bash
#!/bin/bash
# deploy.sh

set -e

# Configuration
IMAGE_NAME="task-manager"
CONTAINER_NAME="task-manager-app"
BACKUP_DIR="/backups/deployments"
HEALTH_CHECK_URL="http://localhost:3000/health"
MAX_WAIT_TIME=60

echo "=== Task Manager Deployment Script ==="
echo "Starting deployment at: $(date)"

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Function to check if service is healthy
check_health() {
    local max_attempts=20
    local attempt=1
    
    echo "Checking application health..."
    
    while [ $attempt -le $max_attempts ]; do
        if curl -f -s "$HEALTH_CHECK_URL" > /dev/null; then
            echo "✅ Application is healthy"
            return 0
        fi
        
        echo "Attempt $attempt/$max_attempts: Application not ready, waiting..."
        sleep 3
        attempt=$((attempt + 1))
    done
    
    echo "❌ Application failed health check"
    return 1
}

# Function to rollback deployment
rollback() {
    echo "🔄 Rolling back deployment..."
    
    if [ -f "$BACKUP_DIR/docker-compose.yml.backup" ]; then
        cp "$BACKUP_DIR/docker-compose.yml.backup" docker-compose.yml
        docker compose up -d
        
        if check_health; then
            echo "✅ Rollback successful"
        else
            echo "❌ Rollback failed - manual intervention required"
            exit 1
        fi
    else
        echo "❌ No backup found for rollback"
        exit 1
    fi
}

# Trap errors and rollback
trap 'rollback' ERR

# Step 1: Backup current configuration
echo "1. Creating backup..."
BACKUP_TIMESTAMP=$(date +%Y%m%d_%H%M%S)
cp docker-compose.yml "$BACKUP_DIR/docker-compose.yml.backup"
docker compose config > "$BACKUP_DIR/docker-compose-$BACKUP_TIMESTAMP.yml"

# Step 2: Pull latest code (if using git)
if [ -d ".git" ]; then
    echo "2. Pulling latest code..."
    git pull origin main
else
    echo "2. Skipping git pull (not a git repository)"
fi

# Step 3: Build new image
echo "3. Building new Docker image..."
docker build -t "$IMAGE_NAME:latest" .
docker tag "$IMAGE_NAME:latest" "$IMAGE_NAME:$BACKUP_TIMESTAMP"

# Step 4: Update services with zero-downtime deployment
echo "4. Deploying new version..."

# Scale up new instance
docker compose up -d --scale app=2 --no-recreate

# Wait for new instance to be healthy
sleep 10
if ! check_health; then
    echo "❌ New instance failed to start"
    exit 1
fi

# Scale down old instance
docker compose up -d --scale app=1 --no-recreate

# Step 5: Clean up old images (keep last 5)
echo "5. Cleaning up old images..."
docker images "$IMAGE_NAME" --format "table {{.Repository}}:{{.Tag}}\t{{.CreatedAt}}" | \
    tail -n +2 | sort -k2 -r | tail -n +6 | awk '{print $1}' | \
    xargs -r docker rmi

# Step 6: Final health check
echo "6. Final health check..."
if check_health; then
    echo "✅ Deployment successful!"
    
    # Clean up backup if deployment is successful
    rm -f "$BACKUP_DIR/docker-compose.yml.backup"
    
    # Log successful deployment
    echo "$(date): Deployment successful - $BACKUP_TIMESTAMP" >> "$BACKUP_DIR/deployment.log"
else
    echo "❌ Final health check failed"
    exit 1
fi

echo "Deployment completed at: $(date)"
```

### Production Commands
```bash
# Deploy to production
chmod +x deploy.sh
./deploy.sh

# View logs
docker compose logs -f app

# Scale application
docker compose up -d --scale app=3

# Update single service
docker compose up -d --no-deps app

# Backup data
docker run --rm -v task-manager_app-data:/data -v $(pwd):/backup alpine tar czf /backup/data-backup-$(date +%Y%m%d).tar.gz -C /data .

# Restore data
docker run --rm -v task-manager_app-data:/data -v $(pwd):/backup alpine tar xzf /backup/data-backup.tar.gz -C /data
```

## Monitoring and Logging

### Prometheus Configuration
```yaml
# monitoring/prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  - "alert_rules.yml"

scrape_configs:
  - job_name: 'task-manager'
    static_configs:
      - targets: ['app:3000']
    metrics_path: '/metrics'
    scrape_interval: 30s

  - job_name: 'nginx'
    static_configs:
      - targets: ['nginx:9113']
    scrape_interval: 30s

  - job_name: 'node-exporter'
    static_configs:
      - targets: ['node-exporter:9100']
    scrape_interval: 30s

alerting:
  alertmanagers:
    - static_configs:
        - targets:
          - alertmanager:9093
```

### Logging Configuration
```yaml
# docker-compose.logging.yml
version: '3.8'

services:
  app:
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
        labels: "service=task-manager"

  nginx:
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
        labels: "service=nginx"

  # ELK Stack for centralized logging
  elasticsearch:
    image: docker.elastic.co/elasticsearch/elasticsearch:8.5.0
    container_name: elasticsearch
    environment:
      - discovery.type=single-node
      - "ES_JAVA_OPTS=-Xms512m -Xmx512m"
      - xpack.security.enabled=false
    volumes:
      - elasticsearch-data:/usr/share/elasticsearch/data
    ports:
      - "9200:9200"
    networks:
      - app-network

  logstash:
    image: docker.elastic.co/logstash/logstash:8.5.0
    container_name: logstash
    volumes:
      - ./logstash/pipeline:/usr/share/logstash/pipeline
      - ./logstash/config:/usr/share/logstash/config
    ports:
      - "5044:5044"
    environment:
      LS_JAVA_OPTS: "-Xmx256m -Xms256m"
    networks:
      - app-network
    depends_on:
      - elasticsearch

  kibana:
    image: docker.elastic.co/kibana/kibana:8.5.0
    container_name: kibana
    ports:
      - "5601:5601"
    environment:
      ELASTICSEARCH_HOSTS: http://elasticsearch:9200
    networks:
      - app-network
    depends_on:
      - elasticsearch

volumes:
  elasticsearch-data:
    driver: local
```

## Troubleshooting

### Common Docker Issues

#### 1. Container Won't Start
```bash
# Check container logs
docker logs task-manager-app

# Check container status
docker ps -a

# Inspect container configuration
docker inspect task-manager-app

# Check resource usage
docker stats

# Check if port is already in use
netstat -tulpn | grep :3000
```

#### 2. Build Failures
```bash
# Build with no cache
docker build --no-cache -t task-manager:latest .

# Build with verbose output
docker build --progress=plain -t task-manager:latest .

# Check disk space
df -h
docker system df

# Clean up build cache
docker builder prune
```

#### 3. Network Issues
```bash
# List networks
docker network ls

# Inspect network
docker network inspect task-manager_app-network

# Test connectivity between containers
docker exec task-manager-app ping nginx
docker exec task-manager-nginx ping app
```

#### 4. Volume Issues
```bash
# List volumes
docker volume ls

# Inspect volume
docker volume inspect task-manager_app-data

# Check volume usage
docker system df -v

# Backup volume
docker run --rm -v task-manager_app-data:/data -v $(pwd):/backup alpine tar czf /backup/volume-backup.tar.gz -C /data .
```

#### 5. Performance Issues
```bash
# Monitor resource usage
docker stats --no-stream

# Check container limits
docker inspect task-manager-app | grep -A 10 "Memory\|Cpu"

# Profile application
docker exec task-manager-app node --prof server.js

# Check logs for performance issues
docker logs task-manager-app | grep -i "slow\|timeout\|error"
```

### Health Check Debugging
```bash
# Test health check manually
docker exec task-manager-app curl -f http://localhost:3000/health

# Check health check configuration
docker inspect task-manager-app | grep -A 10 "Healthcheck"

# View health check logs
docker inspect task-manager-app | grep -A 5 "Health"
```

### Emergency Recovery
```bash
#!/bin/bash
# emergency-docker-recovery.sh

echo "=== Emergency Docker Recovery ==="

# Stop all containers
docker compose down

# Remove problematic containers
docker container prune -f

# Remove unused images
docker image prune -f

# Remove unused volumes (CAUTION: This removes data)
# docker volume prune -f

# Restart with fresh containers
docker compose up -d

# Wait and check health
sleep 30
curl -f http://localhost:3000/health

if [ $? -eq 0 ]; then
    echo "✅ Recovery successful"
else
    echo "❌ Recovery failed - check logs"
    docker compose logs
fi
```

This Docker deployment guide provides a robust foundation for containerizing and deploying your Task Management System with proper monitoring, logging, and troubleshooting capabilities.