#!/bin/bash

# Vercel Deployment Script for Task Management System
# This script automates the deployment process to Vercel

set -e

# Configuration
PROJECT_NAME="task-management-system"
BUILD_DIR="dist"
VERCEL_ORG_ID="${VERCEL_ORG_ID:-}"
VERCEL_PROJECT_ID="${VERCEL_PROJECT_ID:-}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check if Node.js is installed
    if ! command -v node &> /dev/null; then
        log_error "Node.js is not installed. Please install Node.js first."
        exit 1
    fi
    
    # Check if npm is installed
    if ! command -v npm &> /dev/null; then
        log_error "npm is not installed. Please install npm first."
        exit 1
    fi
    
    # Check if Vercel CLI is installed
    if ! command -v vercel &> /dev/null; then
        log_warning "Vercel CLI is not installed. Installing..."
        npm install -g vercel
    fi
    
    log_success "Prerequisites check completed"
}

# Install dependencies
install_dependencies() {
    log_info "Installing dependencies..."
    
    if [ -f "package-lock.json" ]; then
        npm ci
    else
        npm install
    fi
    
    log_success "Dependencies installed"
}

# Run tests
run_tests() {
    log_info "Running tests..."
    
    if npm run test --if-present; then
        log_success "All tests passed"
    else
        log_error "Tests failed. Deployment aborted."
        exit 1
    fi
}

# Build application
build_application() {
    log_info "Building application..."
    
    # Clean previous build
    rm -rf "$BUILD_DIR"
    
    # Create build directory
    mkdir -p "$BUILD_DIR"
    
    # Copy static files
    cp -r public/* "$BUILD_DIR/"
    
    # Copy source files
    cp -r src "$BUILD_DIR/"
    
    # Create vercel.json configuration
    if [ ! -f "vercel.json" ]; then
        log_info "Creating vercel.json configuration..."
        cat > vercel.json << EOF
{
  "version": 2,
  "name": "$PROJECT_NAME",
  "builds": [
    {
      "src": "server.js",
      "use": "@vercel/node"
    },
    {
      "src": "public/**/*",
      "use": "@vercel/static"
    }
  ],
  "routes": [
    {
      "src": "/api/(.*)",
      "dest": "/api/\$1"
    },
    {
      "src": "/health",
      "dest": "/api/health"
    },
    {
      "src": "/static/(.*)",
      "dest": "/public/\$1"
    },
    {
      "src": "/(.*)",
      "dest": "/public/\$1"
    }
  ],
  "env": {
    "NODE_ENV": "production"
  },
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        {
          "key": "X-Frame-Options",
          "value": "DENY"
        },
        {
          "key": "X-XSS-Protection",
          "value": "1; mode=block"
        },
        {
          "key": "X-Content-Type-Options",
          "value": "nosniff"
        },
        {
          "key": "Referrer-Policy",
          "value": "strict-origin-when-cross-origin"
        }
      ]
    },
    {
      "source": "/static/(.*)",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "public, max-age=31536000, immutable"
        }
      ]
    }
  ],
  "functions": {
    "api/**/*.js": {
      "maxDuration": 10
    }
  }
}
EOF
    fi
    
    log_success "Application built successfully"
}

# Create API functions for Vercel
create_api_functions() {
    log_info "Creating Vercel API functions..."
    
    mkdir -p api
    
    # Create health check API
    cat > api/health.js << 'EOF'
export default function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    environment: 'vercel',
    version: process.env.npm_package_version || '1.0.0',
    uptime: process.uptime(),
    memory: process.memoryUsage()
  });
}
EOF
    
    # Create tasks API
    cat > api/tasks/index.js << 'EOF'
// Simple in-memory storage (use a database in production)
let tasks = [];
let nextId = 1;

export default function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  // Handle preflight requests
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    switch (req.method) {
      case 'GET':
        return res.status(200).json(tasks);

      case 'POST':
        const newTask = {
          id: nextId++,
          title: req.body.title,
          description: req.body.description || '',
          completed: false,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        tasks.push(newTask);
        return res.status(201).json(newTask);

      default:
        return res.status(405).json({ error: 'Method not allowed' });
    }
  } catch (error) {
    console.error('API Error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}
EOF
    
    # Create individual task API
    cat > api/tasks/[id].js << 'EOF'
// Simple in-memory storage (use a database in production)
let tasks = [];

export default function handler(req, res) {
  const { id } = req.query;
  const taskId = parseInt(id);

  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  // Handle preflight requests
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    const taskIndex = tasks.findIndex(t => t.id === taskId);

    switch (req.method) {
      case 'GET':
        if (taskIndex === -1) {
          return res.status(404).json({ error: 'Task not found' });
        }
        return res.status(200).json(tasks[taskIndex]);

      case 'PUT':
        if (taskIndex === -1) {
          return res.status(404).json({ error: 'Task not found' });
        }
        
        tasks[taskIndex] = {
          ...tasks[taskIndex],
          ...req.body,
          updatedAt: new Date().toISOString()
        };
        
        return res.status(200).json(tasks[taskIndex]);

      case 'DELETE':
        if (taskIndex === -1) {
          return res.status(404).json({ error: 'Task not found' });
        }
        
        tasks.splice(taskIndex, 1);
        return res.status(204).end();

      default:
        return res.status(405).json({ error: 'Method not allowed' });
    }
  } catch (error) {
    console.error('API Error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}
EOF
    
    # Create metrics API
    cat > api/metrics.js << 'EOF'
export default function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const metrics = {
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    environment: 'vercel',
    version: process.env.npm_package_version || '1.0.0',
    platform: {
      node: process.version,
      arch: process.arch,
      platform: process.platform
    }
  };

  res.status(200).json(metrics);
}
EOF
    
    log_success "Vercel API functions created"
}

# Create package.json scripts for Vercel
update_package_json() {
    log_info "Updating package.json for Vercel deployment..."
    
    # Check if package.json exists
    if [ ! -f "package.json" ]; then
        log_info "Creating package.json..."
        cat > package.json << EOF
{
  "name": "$PROJECT_NAME",
  "version": "1.0.0",
  "description": "Task Management System",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "node server.js",
    "build": "echo 'No build step required for static deployment'",
    "test": "echo 'No tests specified' && exit 0"
  },
  "dependencies": {
    "express": "^4.18.0"
  },
  "engines": {
    "node": ">=18.0.0"
  }
}
EOF
    fi
    
    log_success "Package.json updated"
}

# Deploy to Vercel
deploy_to_vercel() {
    log_info "Deploying to Vercel..."
    
    # Check if user is logged in
    if ! vercel whoami &> /dev/null; then
        log_info "Please log in to Vercel..."
        vercel login
    fi
    
    # Set project configuration if provided
    if [ -n "$VERCEL_ORG_ID" ] && [ -n "$VERCEL_PROJECT_ID" ]; then
        log_info "Using existing project configuration..."
        echo "$VERCEL_ORG_ID" > .vercel/project.json.tmp
        echo "$VERCEL_PROJECT_ID" >> .vercel/project.json.tmp
        
        cat > .vercel/project.json << EOF
{
  "orgId": "$VERCEL_ORG_ID",
  "projectId": "$VERCEL_PROJECT_ID"
}
EOF
    fi
    
    # Deploy to production
    log_info "Deploying to production..."
    vercel --prod --yes
    
    log_success "Deployment completed"
}

# Verify deployment
verify_deployment() {
    log_info "Verifying deployment..."
    
    # Get deployment URL
    DEPLOYMENT_URL=$(vercel ls --json | jq -r '.[0].url' 2>/dev/null || echo "")
    
    if [ -n "$DEPLOYMENT_URL" ]; then
        # Ensure URL has protocol
        if [[ ! "$DEPLOYMENT_URL" =~ ^https?:// ]]; then
            DEPLOYMENT_URL="https://$DEPLOYMENT_URL"
        fi
        
        log_info "Deployment URL: $DEPLOYMENT_URL"
        
        # Test health endpoint
        log_info "Testing health endpoint..."
        if curl -f -s "$DEPLOYMENT_URL/api/health" > /dev/null; then
            log_success "Health check passed"
        else
            log_warning "Health check failed"
        fi
        
        # Test main page
        log_info "Testing main page..."
        if curl -f -s "$DEPLOYMENT_URL" > /dev/null; then
            log_success "Main page is accessible"
        else
            log_error "Main page is not accessible"
            exit 1
        fi
        
        # Test API endpoints
        log_info "Testing API endpoints..."
        if curl -f -s "$DEPLOYMENT_URL/api/tasks" > /dev/null; then
            log_success "Tasks API is accessible"
        else
            log_warning "Tasks API is not accessible"
        fi
        
        log_success "Deployment verification completed"
        log_info "Your site is live at: $DEPLOYMENT_URL"
    else
        log_warning "Could not determine deployment URL"
    fi
}

# Set environment variables
set_environment_variables() {
    log_info "Setting environment variables..."
    
    # Set production environment
    vercel env add NODE_ENV production production --yes 2>/dev/null || true
    
    # Set other environment variables if needed
    # vercel env add DATABASE_URL your-database-url production --yes
    # vercel env add API_KEY your-api-key production --yes
    
    log_success "Environment variables configured"
}

# Configure custom domain (optional)
configure_domain() {
    local domain="$1"
    
    if [ -n "$domain" ]; then
        log_info "Configuring custom domain: $domain"
        
        vercel domains add "$domain" --yes
        
        if [ $? -eq 0 ]; then
            log_success "Domain configured successfully"
            log_info "Please update your DNS records to point to Vercel"
        else
            log_warning "Domain configuration failed"
        fi
    fi
}

# Cleanup
cleanup() {
    log_info "Cleaning up temporary files..."
    rm -f .vercel/project.json.tmp
    log_success "Cleanup completed"
}

# Show post-deployment information
show_post_deployment_info() {
    log_success "🚀 Deployment completed successfully!"
    log_info ""
    log_info "Next steps:"
    log_info "1. Configure custom domain: vercel domains add yourdomain.com"
    log_info "2. Set up environment variables: vercel env add KEY value production"
    log_info "3. Configure analytics: vercel analytics enable"
    log_info "4. Set up monitoring: vercel logs --follow"
    log_info "5. Configure edge functions: https://vercel.com/docs/concepts/functions/edge-functions"
    log_info ""
    log_info "Useful commands:"
    log_info "- View logs: vercel logs"
    log_info "- List deployments: vercel ls"
    log_info "- Remove deployment: vercel rm [deployment-url]"
    log_info "- View project info: vercel project"
}

# Main deployment process
main() {
    log_info "Starting Vercel deployment for $PROJECT_NAME"
    log_info "Timestamp: $(date)"
    
    check_prerequisites
    install_dependencies
    run_tests
    update_package_json
    build_application
    create_api_functions
    set_environment_variables
    deploy_to_vercel
    verify_deployment
    
    # Configure custom domain if provided as argument
    if [ -n "$1" ]; then
        configure_domain "$1"
    fi
    
    cleanup
    show_post_deployment_info
}

# Handle script interruption
trap cleanup EXIT

# Run main function with optional domain argument
main "$@"