# Monitoring and Logging Setup Guide

## Overview
This guide covers setting up comprehensive monitoring and logging for your Task Management System in production. Proper monitoring helps you detect issues early, understand user behavior, and maintain system health.

## Table of Contents
- [Application Monitoring](#application-monitoring)
- [Error Tracking](#error-tracking)
- [Performance Monitoring](#performance-monitoring)
- [Log Management](#log-management)
- [Alerting Setup](#alerting-setup)
- [Dashboard Creation](#dashboard-creation)
- [Troubleshooting](#troubleshooting)

## Application Monitoring

### Basic Health Monitoring

#### Health Check Endpoint
Your application already includes a health check endpoint. Enhance it with more detailed information:

```javascript
// Enhanced health check
app.get('/health', async (req, res) => {
  const healthCheck = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV,
    version: process.env.npm_package_version,
    memory: process.memoryUsage(),
    cpu: process.cpuUsage(),
    
    // Check external dependencies
    dependencies: {
      database: await checkDatabaseHealth(),
      storage: await checkStorageHealth(),
      externalAPIs: await checkExternalAPIs()
    },
    
    // System metrics
    system: {
      loadAverage: os.loadavg(),
      freeMemory: os.freemem(),
      totalMemory: os.totalmem(),
      platform: os.platform(),
      arch: os.arch()
    }
  };

  // Determine overall health status
  const isHealthy = Object.values(healthCheck.dependencies)
    .every(dep => dep.status === 'healthy');
  
  const statusCode = isHealthy ? 200 : 503;
  healthCheck.status = isHealthy ? 'healthy' : 'unhealthy';
  
  res.status(statusCode).json(healthCheck);
});

async function checkDatabaseHealth() {
  try {
    // For localStorage-based app, check if storage is accessible
    const testKey = '__health_check__';
    localStorage.setItem(testKey, 'test');
    localStorage.removeItem(testKey);
    
    return {
      status: 'healthy',
      responseTime: Date.now() - start,
      message: 'Storage accessible'
    };
  } catch (error) {
    return {
      status: 'unhealthy',
      error: error.message,
      message: 'Storage not accessible'
    };
  }
}

async function checkStorageHealth() {
  try {
    const start = Date.now();
    // Check if we can read/write to storage
    const available = typeof(Storage) !== "undefined";
    
    return {
      status: available ? 'healthy' : 'unhealthy',
      responseTime: Date.now() - start,
      message: available ? 'Browser storage available' : 'Browser storage not available'
    };
  } catch (error) {
    return {
      status: 'unhealthy',
      error: error.message
    };
  }
}

async function checkExternalAPIs() {
  // If you integrate with external APIs, check them here
  return {
    status: 'healthy',
    message: 'No external APIs configured'
  };
}
```

#### Uptime Monitoring Services

**Option 1: UptimeRobot (Free)**
1. Sign up at [uptimerobot.com](https://uptimerobot.com)
2. Add HTTP(s) monitor
3. Set URL to your health endpoint: `https://yourapp.com/health`
4. Configure check interval (5 minutes for free plan)
5. Set up email/SMS alerts

**Option 2: Pingdom**
1. Create account at [pingdom.com](https://pingdom.com)
2. Add uptime check
3. Configure advanced settings:
   - Check for specific text in response
   - Set custom headers if needed
   - Configure multiple check locations

**Option 3: StatusCake**
1. Sign up at [statuscake.com](https://statuscake.com)
2. Create uptime test
3. Set up contact groups for alerts
4. Configure maintenance windows

### Custom Monitoring Script

```javascript
// monitoring-client.js
class MonitoringClient {
  constructor(config) {
    this.config = {
      endpoint: config.endpoint || '/health',
      interval: config.interval || 60000, // 1 minute
      retries: config.retries || 3,
      timeout: config.timeout || 5000,
      ...config
    };
    
    this.metrics = {
      uptime: 0,
      downtime: 0,
      lastCheck: null,
      consecutiveFailures: 0,
      totalChecks: 0,
      failedChecks: 0
    };
    
    this.isRunning = false;
  }

  start() {
    if (this.isRunning) return;
    
    this.isRunning = true;
    console.log('Starting health monitoring...');
    
    this.checkHealth();
    this.interval = setInterval(() => {
      this.checkHealth();
    }, this.config.interval);
  }

  stop() {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
    }
    this.isRunning = false;
    console.log('Health monitoring stopped');
  }

  async checkHealth() {
    const startTime = Date.now();
    this.metrics.totalChecks++;
    this.metrics.lastCheck = new Date().toISOString();

    try {
      const response = await this.makeHealthRequest();
      const responseTime = Date.now() - startTime;
      
      if (response.ok) {
        this.handleHealthyResponse(response, responseTime);
      } else {
        this.handleUnhealthyResponse(response, responseTime);
      }
    } catch (error) {
      this.handleError(error, Date.now() - startTime);
    }
  }

  async makeHealthRequest() {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.config.timeout);

    try {
      const response = await fetch(this.config.endpoint, {
        signal: controller.signal,
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'HealthMonitor/1.0'
        }
      });
      
      clearTimeout(timeoutId);
      return response;
    } catch (error) {
      clearTimeout(timeoutId);
      throw error;
    }
  }

  handleHealthyResponse(response, responseTime) {
    this.metrics.consecutiveFailures = 0;
    this.metrics.uptime++;
    
    console.log(`✅ Health check passed (${responseTime}ms)`);
    
    // Log performance metrics
    if (responseTime > 1000) {
      console.warn(`⚠️ Slow response time: ${responseTime}ms`);
    }
  }

  handleUnhealthyResponse(response, responseTime) {
    this.metrics.consecutiveFailures++;
    this.metrics.failedChecks++;
    this.metrics.downtime++;
    
    console.error(`❌ Health check failed: ${response.status} ${response.statusText}`);
    
    if (this.metrics.consecutiveFailures >= 3) {
      this.triggerAlert('Service appears to be down', {
        status: response.status,
        consecutiveFailures: this.metrics.consecutiveFailures,
        responseTime
      });
    }
  }

  handleError(error, responseTime) {
    this.metrics.consecutiveFailures++;
    this.metrics.failedChecks++;
    this.metrics.downtime++;
    
    console.error(`❌ Health check error: ${error.message}`);
    
    if (this.metrics.consecutiveFailures >= 3) {
      this.triggerAlert('Service unreachable', {
        error: error.message,
        consecutiveFailures: this.metrics.consecutiveFailures,
        responseTime
      });
    }
  }

  triggerAlert(message, details) {
    console.error(`🚨 ALERT: ${message}`, details);
    
    // Send alert via webhook, email, etc.
    this.sendAlert(message, details);
  }

  async sendAlert(message, details) {
    // Example: Send to Slack webhook
    if (this.config.slackWebhook) {
      try {
        await fetch(this.config.slackWebhook, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: `🚨 ${message}`,
            attachments: [{
              color: 'danger',
              fields: Object.entries(details).map(([key, value]) => ({
                title: key,
                value: String(value),
                short: true
              }))
            }]
          })
        });
      } catch (error) {
        console.error('Failed to send Slack alert:', error);
      }
    }

    // Example: Send email alert
    if (this.config.emailWebhook) {
      try {
        await fetch(this.config.emailWebhook, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: this.config.alertEmail,
            subject: `Alert: ${message}`,
            body: `Alert Details:\n${JSON.stringify(details, null, 2)}`
          })
        });
      } catch (error) {
        console.error('Failed to send email alert:', error);
      }
    }
  }

  getMetrics() {
    const totalChecks = this.metrics.totalChecks;
    const uptime = totalChecks > 0 ? (this.metrics.uptime / totalChecks) * 100 : 0;
    
    return {
      ...this.metrics,
      uptimePercentage: uptime.toFixed(2),
      isHealthy: this.metrics.consecutiveFailures === 0,
      lastCheckTime: this.metrics.lastCheck
    };
  }
}

// Usage example
const monitor = new MonitoringClient({
  endpoint: 'https://yourapp.com/health',
  interval: 30000, // 30 seconds
  slackWebhook: process.env.SLACK_WEBHOOK_URL,
  emailWebhook: process.env.EMAIL_WEBHOOK_URL,
  alertEmail: process.env.ALERT_EMAIL
});

monitor.start();

// Graceful shutdown
process.on('SIGTERM', () => monitor.stop());
process.on('SIGINT', () => monitor.stop());
```

## Error Tracking

### Client-Side Error Tracking

```javascript
// error-tracker.js
class ErrorTracker {
  constructor(config = {}) {
    this.config = {
      endpoint: config.endpoint || '/api/errors',
      maxErrors: config.maxErrors || 100,
      batchSize: config.batchSize || 10,
      flushInterval: config.flushInterval || 30000,
      ...config
    };
    
    this.errors = [];
    this.setupErrorHandlers();
    this.startBatchProcessor();
  }

  setupErrorHandlers() {
    // Catch JavaScript errors
    window.addEventListener('error', (event) => {
      this.captureError({
        type: 'javascript',
        message: event.message,
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        stack: event.error?.stack,
        timestamp: new Date().toISOString(),
        url: window.location.href,
        userAgent: navigator.userAgent
      });
    });

    // Catch unhandled promise rejections
    window.addEventListener('unhandledrejection', (event) => {
      this.captureError({
        type: 'unhandled_promise',
        message: event.reason?.message || String(event.reason),
        stack: event.reason?.stack,
        timestamp: new Date().toISOString(),
        url: window.location.href,
        userAgent: navigator.userAgent
      });
    });

    // Catch network errors
    const originalFetch = window.fetch;
    window.fetch = async (...args) => {
      try {
        const response = await originalFetch(...args);
        
        if (!response.ok) {
          this.captureError({
            type: 'network',
            message: `HTTP ${response.status}: ${response.statusText}`,
            url: args[0],
            status: response.status,
            timestamp: new Date().toISOString()
          });
        }
        
        return response;
      } catch (error) {
        this.captureError({
          type: 'network',
          message: error.message,
          url: args[0],
          timestamp: new Date().toISOString()
        });
        throw error;
      }
    };
  }

  captureError(errorData) {
    // Add additional context
    const enrichedError = {
      ...errorData,
      id: this.generateErrorId(),
      sessionId: this.getSessionId(),
      userId: this.getUserId(),
      viewport: {
        width: window.innerWidth,
        height: window.innerHeight
      },
      connection: navigator.connection ? {
        effectiveType: navigator.connection.effectiveType,
        downlink: navigator.connection.downlink
      } : null
    };

    this.errors.push(enrichedError);
    
    // Limit stored errors
    if (this.errors.length > this.config.maxErrors) {
      this.errors = this.errors.slice(-this.config.maxErrors);
    }

    console.error('Error captured:', enrichedError);
  }

  generateErrorId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  getSessionId() {
    let sessionId = sessionStorage.getItem('sessionId');
    if (!sessionId) {
      sessionId = this.generateErrorId();
      sessionStorage.setItem('sessionId', sessionId);
    }
    return sessionId;
  }

  getUserId() {
    // Return user ID if available
    return localStorage.getItem('userId') || 'anonymous';
  }

  startBatchProcessor() {
    setInterval(() => {
      this.flushErrors();
    }, this.config.flushInterval);
  }

  async flushErrors() {
    if (this.errors.length === 0) return;

    const batch = this.errors.splice(0, this.config.batchSize);
    
    try {
      await fetch(this.config.endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ errors: batch })
      });
      
      console.log(`Sent ${batch.length} errors to server`);
    } catch (error) {
      // Put errors back if sending failed
      this.errors.unshift(...batch);
      console.error('Failed to send errors:', error);
    }
  }

  // Manual error reporting
  reportError(error, context = {}) {
    this.captureError({
      type: 'manual',
      message: error.message || String(error),
      stack: error.stack,
      context,
      timestamp: new Date().toISOString(),
      url: window.location.href
    });
  }
}

// Initialize error tracking
const errorTracker = new ErrorTracker({
  endpoint: '/api/errors'
});

// Make it globally available
window.errorTracker = errorTracker;
```

### Server-Side Error Handling

```javascript
// server-error-handler.js
const fs = require('fs').promises;
const path = require('path');

class ServerErrorHandler {
  constructor(config = {}) {
    this.config = {
      logDir: config.logDir || './logs',
      maxLogSize: config.maxLogSize || 10 * 1024 * 1024, // 10MB
      maxLogFiles: config.maxLogFiles || 5,
      alertThreshold: config.alertThreshold || 10, // errors per minute
      ...config
    };
    
    this.errorCounts = new Map();
    this.setupLogDirectory();
    this.startErrorCountReset();
  }

  async setupLogDirectory() {
    try {
      await fs.mkdir(this.config.logDir, { recursive: true });
    } catch (error) {
      console.error('Failed to create log directory:', error);
    }
  }

  startErrorCountReset() {
    // Reset error counts every minute
    setInterval(() => {
      this.errorCounts.clear();
    }, 60000);
  }

  async logError(error, context = {}) {
    const errorEntry = {
      timestamp: new Date().toISOString(),
      level: 'error',
      message: error.message,
      stack: error.stack,
      context,
      pid: process.pid,
      memory: process.memoryUsage(),
      uptime: process.uptime()
    };

    // Write to log file
    await this.writeToLogFile(errorEntry);
    
    // Track error frequency
    this.trackErrorFrequency(error);
    
    // Check if we need to send alerts
    this.checkAlertThreshold(error);
    
    console.error('Error logged:', errorEntry);
  }

  async writeToLogFile(errorEntry) {
    const logFileName = `error-${new Date().toISOString().split('T')[0]}.log`;
    const logFilePath = path.join(this.config.logDir, logFileName);
    
    try {
      const logLine = JSON.stringify(errorEntry) + '\n';
      await fs.appendFile(logFilePath, logLine);
      
      // Rotate log if it's too large
      await this.rotateLogIfNeeded(logFilePath);
    } catch (error) {
      console.error('Failed to write to log file:', error);
    }
  }

  async rotateLogIfNeeded(logFilePath) {
    try {
      const stats = await fs.stat(logFilePath);
      
      if (stats.size > this.config.maxLogSize) {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const rotatedPath = `${logFilePath}.${timestamp}`;
        
        await fs.rename(logFilePath, rotatedPath);
        
        // Clean up old log files
        await this.cleanupOldLogs();
      }
    } catch (error) {
      console.error('Failed to rotate log file:', error);
    }
  }

  async cleanupOldLogs() {
    try {
      const files = await fs.readdir(this.config.logDir);
      const logFiles = files
        .filter(file => file.startsWith('error-') && file.endsWith('.log'))
        .map(file => ({
          name: file,
          path: path.join(this.config.logDir, file)
        }));

      if (logFiles.length > this.config.maxLogFiles) {
        // Sort by modification time and remove oldest
        const filesWithStats = await Promise.all(
          logFiles.map(async file => ({
            ...file,
            stats: await fs.stat(file.path)
          }))
        );

        filesWithStats
          .sort((a, b) => a.stats.mtime - b.stats.mtime)
          .slice(0, filesWithStats.length - this.config.maxLogFiles)
          .forEach(async file => {
            await fs.unlink(file.path);
            console.log(`Removed old log file: ${file.name}`);
          });
      }
    } catch (error) {
      console.error('Failed to cleanup old logs:', error);
    }
  }

  trackErrorFrequency(error) {
    const errorKey = `${error.name}:${error.message}`;
    const count = this.errorCounts.get(errorKey) || 0;
    this.errorCounts.set(errorKey, count + 1);
  }

  checkAlertThreshold(error) {
    const errorKey = `${error.name}:${error.message}`;
    const count = this.errorCounts.get(errorKey) || 0;
    
    if (count >= this.config.alertThreshold) {
      this.sendAlert(`High error frequency detected: ${errorKey}`, {
        count,
        threshold: this.config.alertThreshold,
        error: {
          name: error.name,
          message: error.message
        }
      });
    }
  }

  async sendAlert(message, details) {
    console.error(`🚨 ALERT: ${message}`, details);
    
    // Send to external alerting service
    if (this.config.webhookUrl) {
      try {
        await fetch(this.config.webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            alert: message,
            details,
            timestamp: new Date().toISOString()
          })
        });
      } catch (error) {
        console.error('Failed to send alert:', error);
      }
    }
  }

  // Express middleware
  middleware() {
    return async (error, req, res, next) => {
      await this.logError(error, {
        method: req.method,
        url: req.url,
        headers: req.headers,
        body: req.body,
        ip: req.ip,
        userAgent: req.get('User-Agent')
      });

      // Don't expose internal errors in production
      const isDevelopment = process.env.NODE_ENV === 'development';
      
      res.status(error.status || 500).json({
        error: error.name || 'Internal Server Error',
        message: isDevelopment ? error.message : 'Something went wrong',
        ...(isDevelopment && { stack: error.stack })
      });
    };
  }

  // Client error endpoint
  clientErrorHandler() {
    return async (req, res) => {
      const { errors } = req.body;
      
      if (!Array.isArray(errors)) {
        return res.status(400).json({ error: 'Invalid error format' });
      }

      for (const errorData of errors) {
        const error = new Error(errorData.message);
        error.name = errorData.type || 'ClientError';
        error.stack = errorData.stack;
        
        await this.logError(error, {
          source: 'client',
          url: errorData.url,
          userAgent: errorData.userAgent,
          sessionId: errorData.sessionId,
          userId: errorData.userId,
          viewport: errorData.viewport
        });
      }

      res.status(200).json({ received: errors.length });
    };
  }
}

module.exports = ServerErrorHandler;
```

## Performance Monitoring

### Client-Side Performance Tracking

```javascript
// performance-monitor.js
class PerformanceMonitor {
  constructor(config = {}) {
    this.config = {
      endpoint: '/api/performance',
      sampleRate: config.sampleRate || 0.1, // 10% sampling
      batchSize: config.batchSize || 20,
      flushInterval: config.flushInterval || 30000,
      ...config
    };
    
    this.metrics = [];
    this.setupPerformanceObservers();
    this.startBatchProcessor();
  }

  setupPerformanceObservers() {
    // Navigation timing
    window.addEventListener('load', () => {
      setTimeout(() => {
        this.captureNavigationTiming();
      }, 0);
    });

    // Resource timing
    if ('PerformanceObserver' in window) {
      const resourceObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          this.captureResourceTiming(entry);
        }
      });
      resourceObserver.observe({ entryTypes: ['resource'] });

      // Long tasks (performance issues)
      const longTaskObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          this.captureLongTask(entry);
        }
      });
      longTaskObserver.observe({ entryTypes: ['longtask'] });

      // Layout shifts
      const layoutShiftObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          this.captureLayoutShift(entry);
        }
      });
      layoutShiftObserver.observe({ entryTypes: ['layout-shift'] });
    }
  }

  captureNavigationTiming() {
    if (Math.random() > this.config.sampleRate) return;

    const navigation = performance.getEntriesByType('navigation')[0];
    if (!navigation) return;

    this.addMetric({
      type: 'navigation',
      timestamp: Date.now(),
      metrics: {
        dns: navigation.domainLookupEnd - navigation.domainLookupStart,
        tcp: navigation.connectEnd - navigation.connectStart,
        ssl: navigation.secureConnectionStart > 0 
          ? navigation.connectEnd - navigation.secureConnectionStart 
          : 0,
        ttfb: navigation.responseStart - navigation.requestStart,
        download: navigation.responseEnd - navigation.responseStart,
        domParse: navigation.domContentLoadedEventStart - navigation.responseEnd,
        domReady: navigation.domContentLoadedEventEnd - navigation.domContentLoadedEventStart,
        loadComplete: navigation.loadEventEnd - navigation.loadEventStart,
        total: navigation.loadEventEnd - navigation.navigationStart
      },
      url: window.location.href,
      userAgent: navigator.userAgent
    });
  }

  captureResourceTiming(entry) {
    if (Math.random() > this.config.sampleRate) return;

    this.addMetric({
      type: 'resource',
      timestamp: Date.now(),
      resource: {
        name: entry.name,
        type: entry.initiatorType,
        size: entry.transferSize,
        duration: entry.duration,
        blocked: entry.domainLookupStart - entry.fetchStart,
        dns: entry.domainLookupEnd - entry.domainLookupStart,
        connect: entry.connectEnd - entry.connectStart,
        send: entry.responseStart - entry.requestStart,
        wait: entry.responseStart - entry.requestStart,
        receive: entry.responseEnd - entry.responseStart
      }
    });
  }

  captureLongTask(entry) {
    this.addMetric({
      type: 'longtask',
      timestamp: Date.now(),
      task: {
        duration: entry.duration,
        startTime: entry.startTime,
        name: entry.name
      },
      url: window.location.href
    });
  }

  captureLayoutShift(entry) {
    if (!entry.hadRecentInput) {
      this.addMetric({
        type: 'layout-shift',
        timestamp: Date.now(),
        shift: {
          value: entry.value,
          sources: entry.sources?.map(source => ({
            node: source.node?.tagName,
            previousRect: source.previousRect,
            currentRect: source.currentRect
          }))
        },
        url: window.location.href
      });
    }
  }

  // Custom timing measurements
  startTiming(name) {
    performance.mark(`${name}-start`);
  }

  endTiming(name) {
    performance.mark(`${name}-end`);
    performance.measure(name, `${name}-start`, `${name}-end`);
    
    const measure = performance.getEntriesByName(name, 'measure')[0];
    if (measure) {
      this.addMetric({
        type: 'custom-timing',
        timestamp: Date.now(),
        timing: {
          name,
          duration: measure.duration,
          startTime: measure.startTime
        },
        url: window.location.href
      });
    }
  }

  addMetric(metric) {
    this.metrics.push(metric);
    
    if (this.metrics.length > 1000) {
      this.metrics = this.metrics.slice(-1000);
    }
  }

  startBatchProcessor() {
    setInterval(() => {
      this.flushMetrics();
    }, this.config.flushInterval);
  }

  async flushMetrics() {
    if (this.metrics.length === 0) return;

    const batch = this.metrics.splice(0, this.config.batchSize);
    
    try {
      await fetch(this.config.endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ metrics: batch })
      });
      
      console.log(`Sent ${batch.length} performance metrics`);
    } catch (error) {
      // Put metrics back if sending failed
      this.metrics.unshift(...batch);
      console.error('Failed to send performance metrics:', error);
    }
  }

  // Get current performance metrics
  getCurrentMetrics() {
    return {
      memory: performance.memory ? {
        used: performance.memory.usedJSHeapSize,
        total: performance.memory.totalJSHeapSize,
        limit: performance.memory.jsHeapSizeLimit
      } : null,
      timing: performance.timing,
      navigation: performance.navigation,
      connection: navigator.connection ? {
        effectiveType: navigator.connection.effectiveType,
        downlink: navigator.connection.downlink,
        rtt: navigator.connection.rtt
      } : null
    };
  }
}

// Initialize performance monitoring
const performanceMonitor = new PerformanceMonitor({
  endpoint: '/api/performance',
  sampleRate: 0.2 // 20% sampling rate
});

// Make it globally available
window.performanceMonitor = performanceMonitor;

// Example usage for custom timings
// performanceMonitor.startTiming('task-creation');
// // ... task creation code ...
// performanceMonitor.endTiming('task-creation');
```

## Log Management

### Structured Logging Implementation

```javascript
// logger.js
const fs = require('fs').promises;
const path = require('path');

class Logger {
  constructor(config = {}) {
    this.config = {
      level: config.level || 'info',
      format: config.format || 'json',
      logDir: config.logDir || './logs',
      maxFileSize: config.maxFileSize || 10 * 1024 * 1024, // 10MB
      maxFiles: config.maxFiles || 5,
      enableConsole: config.enableConsole !== false,
      ...config
    };
    
    this.levels = {
      error: 0,
      warn: 1,
      info: 2,
      debug: 3
    };
    
    this.setupLogDirectory();
  }

  async setupLogDirectory() {
    try {
      await fs.mkdir(this.config.logDir, { recursive: true });
    } catch (error) {
      console.error('Failed to create log directory:', error);
    }
  }

  shouldLog(level) {
    return this.levels[level] <= this.levels[this.config.level];
  }

  async log(level, message, meta = {}) {
    if (!this.shouldLog(level)) return;

    const logEntry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      ...meta,
      pid: process.pid,
      hostname: require('os').hostname(),
      memory: process.memoryUsage(),
      uptime: process.uptime()
    };

    // Console output
    if (this.config.enableConsole) {
      this.logToConsole(logEntry);
    }

    // File output
    await this.logToFile(logEntry);
  }

  logToConsole(entry) {
    const colors = {
      error: '\x1b[31m', // Red
      warn: '\x1b[33m',  // Yellow
      info: '\x1b[36m',  // Cyan
      debug: '\x1b[37m'  // White
    };
    
    const reset = '\x1b[0m';
    const color = colors[entry.level] || colors.info;
    
    if (this.config.format === 'json') {
      console.log(`${color}${JSON.stringify(entry)}${reset}`);
    } else {
      console.log(`${color}[${entry.timestamp}] ${entry.level.toUpperCase()}: ${entry.message}${reset}`);
    }
  }

  async logToFile(entry) {
    const logFileName = `app-${new Date().toISOString().split('T')[0]}.log`;
    const logFilePath = path.join(this.config.logDir, logFileName);
    
    try {
      const logLine = JSON.stringify(entry) + '\n';
      await fs.appendFile(logFilePath, logLine);
      
      // Rotate if needed
      await this.rotateLogIfNeeded(logFilePath);
    } catch (error) {
      console.error('Failed to write to log file:', error);
    }
  }

  async rotateLogIfNeeded(logFilePath) {
    try {
      const stats = await fs.stat(logFilePath);
      
      if (stats.size > this.config.maxFileSize) {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const rotatedPath = `${logFilePath}.${timestamp}`;
        
        await fs.rename(logFilePath, rotatedPath);
        await this.cleanupOldLogs();
      }
    } catch (error) {
      console.error('Failed to rotate log file:', error);
    }
  }

  async cleanupOldLogs() {
    try {
      const files = await fs.readdir(this.config.logDir);
      const logFiles = files
        .filter(file => file.startsWith('app-') && file.includes('.log'))
        .map(file => ({
          name: file,
          path: path.join(this.config.logDir, file)
        }));

      if (logFiles.length > this.config.maxFiles) {
        const filesWithStats = await Promise.all(
          logFiles.map(async file => ({
            ...file,
            stats: await fs.stat(file.path)
          }))
        );

        filesWithStats
          .sort((a, b) => a.stats.mtime - b.stats.mtime)
          .slice(0, filesWithStats.length - this.config.maxFiles)
          .forEach(async file => {
            await fs.unlink(file.path);
            console.log(`Removed old log file: ${file.name}`);
          });
      }
    } catch (error) {
      console.error('Failed to cleanup old logs:', error);
    }
  }

  // Convenience methods
  error(message, meta) {
    return this.log('error', message, meta);
  }

  warn(message, meta) {
    return this.log('warn', message, meta);
  }

  info(message, meta) {
    return this.log('info', message, meta);
  }

  debug(message, meta) {
    return this.log('debug', message, meta);
  }

  // Express middleware
  middleware() {
    return (req, res, next) => {
      const start = Date.now();
      
      res.on('finish', () => {
        const duration = Date.now() - start;
        
        this.info('HTTP Request', {
          method: req.method,
          url: req.url,
          status: res.statusCode,
          duration,
          ip: req.ip,
          userAgent: req.get('User-Agent'),
          contentLength: res.get('Content-Length')
        });
      });
      
      next();
    };
  }
}

module.exports = Logger;
```

## Alerting Setup

### Alert Configuration

```javascript
// alerting.js
class AlertManager {
  constructor(config = {}) {
    this.config = {
      channels: config.channels || [],
      rules: config.rules || [],
      cooldownPeriod: config.cooldownPeriod || 300000, // 5 minutes
      ...config
    };
    
    this.alertHistory = new Map();
  }

  async sendAlert(rule, data) {
    const alertKey = `${rule.name}-${JSON.stringify(data)}`;
    const lastAlert = this.alertHistory.get(alertKey);
    
    // Check cooldown period
    if (lastAlert && Date.now() - lastAlert < this.config.cooldownPeriod) {
      return;
    }

    this.alertHistory.set(alertKey, Date.now());
    
    const alert = {
      rule: rule.name,
      severity: rule.severity || 'warning',
      message: rule.message,
      data,
      timestamp: new Date().toISOString()
    };

    // Send to all configured channels
    for (const channel of this.config.channels) {
      try {
        await this.sendToChannel(channel, alert);
      } catch (error) {
        console.error(`Failed to send alert to ${channel.type}:`, error);
      }
    }
  }

  async sendToChannel(channel, alert) {
    switch (channel.type) {
      case 'slack':
        await this.sendSlackAlert(channel, alert);
        break;
      case 'email':
        await this.sendEmailAlert(channel, alert);
        break;
      case 'webhook':
        await this.sendWebhookAlert(channel, alert);
        break;
      case 'console':
        this.sendConsoleAlert(alert);
        break;
      default:
        console.warn(`Unknown alert channel type: ${channel.type}`);
    }
  }

  async sendSlackAlert(channel, alert) {
    const color = {
      critical: 'danger',
      warning: 'warning',
      info: 'good'
    }[alert.severity] || 'warning';

    const payload = {
      text: `🚨 ${alert.rule}: ${alert.message}`,
      attachments: [{
        color,
        fields: [
          {
            title: 'Severity',
            value: alert.severity,
            short: true
          },
          {
            title: 'Time',
            value: alert.timestamp,
            short: true
          },
          ...Object.entries(alert.data).map(([key, value]) => ({
            title: key,
            value: String(value),
            short: true
          }))
        ]
      }]
    };

    await fetch(channel.webhook, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
  }

  async sendEmailAlert(channel, alert) {
    // This would integrate with your email service
    const emailData = {
      to: channel.recipients,
      subject: `Alert: ${alert.rule}`,
      html: `
        <h2>🚨 ${alert.rule}</h2>
        <p><strong>Message:</strong> ${alert.message}</p>
        <p><strong>Severity:</strong> ${alert.severity}</p>
        <p><strong>Time:</strong> ${alert.timestamp}</p>
        <h3>Details:</h3>
        <pre>${JSON.stringify(alert.data, null, 2)}</pre>
      `
    };

    // Send via your email service (SendGrid, SES, etc.)
    console.log('Email alert would be sent:', emailData);
  }

  async sendWebhookAlert(channel, alert) {
    await fetch(channel.url, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        ...channel.headers
      },
      body: JSON.stringify(alert)
    });
  }

  sendConsoleAlert(alert) {
    const emoji = {
      critical: '🔥',
      warning: '⚠️',
      info: 'ℹ️'
    }[alert.severity] || '⚠️';

    console.error(`${emoji} ALERT [${alert.severity.toUpperCase()}]: ${alert.rule}`);
    console.error(`Message: ${alert.message}`);
    console.error(`Data:`, alert.data);
  }

  // Check alert rules
  checkRules(metrics) {
    for (const rule of this.config.rules) {
      try {
        if (rule.condition(metrics)) {
          this.sendAlert(rule, metrics);
        }
      } catch (error) {
        console.error(`Error checking rule ${rule.name}:`, error);
      }
    }
  }
}

// Example alert rules
const alertRules = [
  {
    name: 'High Error Rate',
    severity: 'critical',
    message: 'Error rate is above threshold',
    condition: (metrics) => metrics.errorRate > 0.05 // 5%
  },
  {
    name: 'High Response Time',
    severity: 'warning',
    message: 'Average response time is high',
    condition: (metrics) => metrics.averageResponseTime > 2000 // 2 seconds
  },
  {
    name: 'High Memory Usage',
    severity: 'warning',
    message: 'Memory usage is high',
    condition: (metrics) => {
      const memUsage = metrics.memoryUsage;
      return memUsage && (memUsage.heapUsed / memUsage.heapTotal) > 0.9; // 90%
    }
  },
  {
    name: 'Service Down',
    severity: 'critical',
    message: 'Service appears to be down',
    condition: (metrics) => metrics.consecutiveFailures >= 3
  }
];

// Example configuration
const alertManager = new AlertManager({
  channels: [
    {
      type: 'slack',
      webhook: process.env.SLACK_WEBHOOK_URL
    },
    {
      type: 'email',
      recipients: ['admin@example.com']
    },
    {
      type: 'console'
    }
  ],
  rules: alertRules,
  cooldownPeriod: 300000 // 5 minutes
});

module.exports = AlertManager;
```

## Dashboard Creation

### Simple Monitoring Dashboard

```html
<!-- monitoring-dashboard.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Manager - Monitoring Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }
        
        .dashboard {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .metric-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .metric-value {
            font-size: 2em;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .metric-label {
            color: #666;
            font-size: 0.9em;
        }
        
        .status-indicator {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 8px;
        }
        
        .status-healthy { background-color: #4CAF50; }
        .status-warning { background-color: #FF9800; }
        .status-error { background-color: #F44336; }
        
        .chart-container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .logs-container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            max-height: 400px;
            overflow-y: auto;
        }
        
        .log-entry {
            padding: 8px;
            border-bottom: 1px solid #eee;
            font-family: monospace;
            font-size: 0.9em;
        }
        
        .log-error { background-color: #ffebee; }
        .log-warning { background-color: #fff3e0; }
        .log-info { background-color: #e3f2fd; }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="header">
            <h1>Task Manager Monitoring Dashboard</h1>
            <p>Real-time monitoring and metrics for your application</p>
        </div>
        
        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-value" id="uptime">--</div>
                <div class="metric-label">
                    <span class="status-indicator" id="status-indicator"></span>
                    System Status
                </div>
            </div>
            
            <div class="metric-card">
                <div class="metric-value" id="response-time">--</div>
                <div class="metric-label">Avg Response Time (ms)</div>
            </div>
            
            <div class="metric-card">
                <div class="metric-value" id="error-rate">--</div>
                <div class="metric-label">Error Rate (%)</div>
            </div>
            
            <div class="metric-card">
                <div class="metric-value" id="memory-usage">--</div>
                <div class="metric-label">Memory Usage (%)</div>
            </div>
        </div>
        
        <div class="chart-container">
            <h3>Response Time Trend</h3>
            <canvas id="responseTimeChart" width="400" height="200"></canvas>
        </div>
        
        <div class="chart-container">
            <h3>Error Rate Trend</h3>
            <canvas id="errorRateChart" width="400" height="200"></canvas>
        </div>
        
        <div class="logs-container">
            <h3>Recent Logs</h3>
            <div id="logs"></div>
        </div>
    </div>

    <script>
        class MonitoringDashboard {
            constructor() {
                this.setupCharts();
                this.startDataCollection();
            }

            setupCharts() {
                // Response Time Chart
                const responseTimeCtx = document.getElementById('responseTimeChart').getContext('2d');
                this.responseTimeChart = new Chart(responseTimeCtx, {
                    type: 'line',
                    data: {
                        labels: [],
                        datasets: [{
                            label: 'Response Time (ms)',
                            data: [],
                            borderColor: 'rgb(75, 192, 192)',
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            tension: 0.1
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });

                // Error Rate Chart
                const errorRateCtx = document.getElementById('errorRateChart').getContext('2d');
                this.errorRateChart = new Chart(errorRateCtx, {
                    type: 'line',
                    data: {
                        labels: [],
                        datasets: [{
                            label: 'Error Rate (%)',
                            data: [],
                            borderColor: 'rgb(255, 99, 132)',
                            backgroundColor: 'rgba(255, 99, 132, 0.2)',
                            tension: 0.1
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true,
                                max: 100
                            }
                        }
                    }
                });
            }

            startDataCollection() {
                // Update metrics every 30 seconds
                this.updateMetrics();
                setInterval(() => {
                    this.updateMetrics();
                }, 30000);

                // Update logs every 10 seconds
                this.updateLogs();
                setInterval(() => {
                    this.updateLogs();
                }, 10000);
            }

            async updateMetrics() {
                try {
                    const response = await fetch('/health');
                    const health = await response.json();
                    
                    // Update status indicator
                    const statusIndicator = document.getElementById('status-indicator');
                    const uptimeElement = document.getElementById('uptime');
                    
                    if (response.ok && health.status === 'healthy') {
                        statusIndicator.className = 'status-indicator status-healthy';
                        uptimeElement.textContent = this.formatUptime(health.uptime);
                    } else {
                        statusIndicator.className = 'status-indicator status-error';
                        uptimeElement.textContent = 'Down';
                    }

                    // Get performance metrics
                    const metricsResponse = await fetch('/metrics');
                    if (metricsResponse.ok) {
                        const metrics = await metricsResponse.json();
                        this.updateMetricCards(metrics);
                        this.updateCharts(metrics);
                    }
                } catch (error) {
                    console.error('Failed to update metrics:', error);
                    document.getElementById('status-indicator').className = 'status-indicator status-error';
                    document.getElementById('uptime').textContent = 'Error';
                }
            }

            updateMetricCards(metrics) {
                // Response time
                const responseTime = metrics.averageResponseTime || 0;
                document.getElementById('response-time').textContent = Math.round(responseTime);

                // Error rate
                const errorRate = (metrics.errorRate || 0) * 100;
                document.getElementById('error-rate').textContent = errorRate.toFixed(2);

                // Memory usage
                if (metrics.memoryUsage) {
                    const memoryPercent = (metrics.memoryUsage.heapUsed / metrics.memoryUsage.heapTotal) * 100;
                    document.getElementById('memory-usage').textContent = memoryPercent.toFixed(1);
                }
            }

            updateCharts(metrics) {
                const now = new Date().toLocaleTimeString();
                
                // Response Time Chart
                this.responseTimeChart.data.labels.push(now);
                this.responseTimeChart.data.datasets[0].data.push(metrics.averageResponseTime || 0);
                
                // Keep only last 20 data points
                if (this.responseTimeChart.data.labels.length > 20) {
                    this.responseTimeChart.data.labels.shift();
                    this.responseTimeChart.data.datasets[0].data.shift();
                }
                
                this.responseTimeChart.update();

                // Error Rate Chart
                this.errorRateChart.data.labels.push(now);
                this.errorRateChart.data.datasets[0].data.push((metrics.errorRate || 0) * 100);
                
                if (this.errorRateChart.data.labels.length > 20) {
                    this.errorRateChart.data.labels.shift();
                    this.errorRateChart.data.datasets[0].data.shift();
                }
                
                this.errorRateChart.update();
            }

            async updateLogs() {
                try {
                    const response = await fetch('/api/logs?limit=50');
                    if (response.ok) {
                        const logs = await response.json();
                        this.displayLogs(logs);
                    }
                } catch (error) {
                    console.error('Failed to update logs:', error);
                }
            }

            displayLogs(logs) {
                const logsContainer = document.getElementById('logs');
                logsContainer.innerHTML = '';

                logs.forEach(log => {
                    const logEntry = document.createElement('div');
                    logEntry.className = `log-entry log-${log.level}`;
                    logEntry.innerHTML = `
                        <strong>[${new Date(log.timestamp).toLocaleString()}]</strong>
                        <span style="text-transform: uppercase; font-weight: bold;">${log.level}</span>:
                        ${log.message}
                    `;
                    logsContainer.appendChild(logEntry);
                });
            }

            formatUptime(seconds) {
                const days = Math.floor(seconds / 86400);
                const hours = Math.floor((seconds % 86400) / 3600);
                const minutes = Math.floor((seconds % 3600) / 60);
                
                if (days > 0) {
                    return `${days}d ${hours}h ${minutes}m`;
                } else if (hours > 0) {
                    return `${hours}h ${minutes}m`;
                } else {
                    return `${minutes}m`;
                }
            }
        }

        // Initialize dashboard when page loads
        document.addEventListener('DOMContentLoaded', () => {
            new MonitoringDashboard();
        });
    </script>
</body>
</html>
```

## Troubleshooting

### Common Monitoring Issues

#### 1. High Memory Usage
```bash
# Check memory usage
free -h
ps aux --sort=-%mem | head

# Node.js specific
node --max-old-space-size=4096 server.js
```

#### 2. High CPU Usage
```bash
# Check CPU usage
top
htop

# Profile Node.js application
node --prof server.js
node --prof-process isolate-*.log > processed.txt
```

#### 3. Disk Space Issues
```bash
# Check disk usage
df -h
du -sh /var/log/*

# Clean up logs
find /var/log -name "*.log" -mtime +7 -delete
```

#### 4. Network Issues
```bash
# Check network connections
netstat -tulpn
ss -tulpn

# Test connectivity
curl -I https://yourapp.com/health
```

### Monitoring Best Practices

1. **Set up alerts for critical metrics**
   - Response time > 2 seconds
   - Error rate > 5%
   - Memory usage > 90%
   - Disk usage > 85%

2. **Monitor business metrics**
   - User registrations
   - Task creation rate
   - Active users
   - Feature usage

3. **Regular maintenance**
   - Review logs weekly
   - Update monitoring thresholds
   - Test alert channels monthly
   - Archive old metrics data

4. **Security monitoring**
   - Failed login attempts
   - Unusual traffic patterns
   - Security header violations
   - Dependency vulnerabilities

This comprehensive monitoring setup will help you maintain a healthy production application and quickly identify and resolve issues before they impact users.